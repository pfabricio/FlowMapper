using System.Data;
using FlowMapper.Execution;
using FlowMapper.Execution.Artifacts;
using FlowMapper.Materializer.Pipeline;

namespace FlowMapper.Materializer;

public class Materializer : IMaterializer
{
    private readonly MaterializationPipeline _pipeline;

    public Materializer() : this(new MaterializationPipeline()) { }

    public Materializer(MaterializationPipeline pipeline)
    {
        _pipeline = pipeline;
    }

    public T Materialize<T>(IDataReader reader, MaterializationPlan plan)
    {
        var artifact = ConvertToArtifact<T>(plan);
        return _pipeline.Materialize<T>(reader, artifact);
    }

    public IEnumerable<T> MaterializeAll<T>(IDataReader reader, MaterializationPlan plan)
    {
        var artifact = ConvertToArtifact<T>(plan);
        return _pipeline.MaterializeAll<T>(reader, artifact);
    }

    public T Materialize<T>(IDataReader reader, IMaterializationArtifact artifact)
    {
        return _pipeline.Materialize<T>(reader, artifact);
    }

    public IEnumerable<T> MaterializeAll<T>(IDataReader reader, IMaterializationArtifact artifact)
    {
        return _pipeline.MaterializeAll<T>(reader, artifact);
    }

    public static MaterializationPlan BuildPlan<T>()
    {
        var plan = new MaterializationPlan { TargetType = typeof(T) };
        var props = typeof(T).GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance)
            .Where(p => p.CanWrite);

        foreach (var prop in props)
        {
            plan.Bindings.Add(new MaterializationBinding
            {
                ColumnName = prop.Name,
                PropertyName = prop.Name,
                PropertyType = prop.PropertyType
            });
        }

        return plan;
    }

    private static IMaterializationArtifact ConvertToArtifact<T>(MaterializationPlan plan)
    {
        var bindings = plan.Bindings.Select(b => new ColumnBinding(
            b.ColumnName,
            b.PropertyName,
            b.PropertyType,
            Converter: null,
            IsNullable: Nullable.GetUnderlyingType(b.PropertyType) != null || !b.PropertyType.IsValueType
        )).ToArray();

        return new MaterializationArtifact(
            Name: $"Materialize_{typeof(T).Name}",
            Version: new Version(2, 0),
            TargetType: typeof(T),
            ConstructorDelegate: null,
            ColumnBindings: bindings,
            MaterializationDelegate: null
        );
    }
}

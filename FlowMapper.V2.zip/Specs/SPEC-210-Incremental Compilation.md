# SPEC-210 — Incremental Compilation

## Status

Implemented

----------

# Purpose

Definir a arquitetura oficial de **Incremental Compilation** do FlowMapper V2.

Incremental Compilation permite recompilar apenas os componentes afetados por uma alteração, evitando recompilações completas da aplicação.

A compilação incremental é baseada em um **Dependency Graph**, permitindo identificar exatamente quais Artifacts e Execution Plans devem ser regenerados.

----------

# Motivation

Em aplicações grandes, recompilar todos os Profiles e gerar novamente todos os Execution Artifacts aumenta significativamente o tempo de Build.

Grande parte dessas recompilações é desnecessária.

Ao identificar apenas os elementos impactados por uma alteração, o Compiler reduz tempo de compilação, consumo de CPU e geração de código.

----------

# Goals

A arquitetura deve:

-   recompilar apenas componentes afetados;
    
-   reutilizar Artifacts válidos;
    
-   reduzir tempo de Build;
    
-   reduzir consumo de memória;
    
-   reutilizar Metadata;
    
-   suportar Source Generators;
    
-   manter compatibilidade com Native AOT.
    

----------

# Non Goals

Esta SPEC não define:

-   Metadata Builder;
    
-   Validation Engine;
    
-   Execution Plans;
    
-   Source Generator.
    

Ela define apenas o mecanismo responsável por determinar o que deve ser recompilado.

----------

# Architecture

```text
Application
      │
      ▼
Metadata Model
      │
      ▼
Dependency Graph
      │
      ▼
Change Analysis
      │
      ▼
Incremental Compiler
      │
      ▼
Execution Artifacts
      │
      ▼
Execution Plans

```

Toda recompilação é baseada no grafo de dependências.

----------

# Responsibilities

O Incremental Compiler é responsável por:

-   detectar alterações;
    
-   identificar dependências afetadas;
    
-   invalidar Artifacts;
    
-   recompilar apenas os componentes necessários;
    
-   reutilizar resultados válidos.
    

Ele nunca executa lógica de Runtime.

----------

# Dependency Graph

O Compiler mantém um grafo representando todas as dependências da compilação.

Exemplo:

```text
Customer
      │
      ▼
CustomerProfile
      │
      ▼
Customer Mapping Artifact
      │
      ▼
Customer Execution Plan

```

Cada nó conhece suas dependências diretas.

----------

# Change Detection

Toda alteração inicia uma nova análise.

```text
Source Change
      │
      ▼
Dependency Analysis
      │
      ▼
Affected Nodes

```

A alteração pode ocorrer em:

-   tipos;
    
-   Profiles;
    
-   Providers;
    
-   configurações;
    
-   código gerado.
    

----------

# Invalidation

Após detectar uma alteração, apenas os nós afetados são invalidados.

```text
Customer Type

↓

Invalidate

↓

Customer Artifact

↓

Customer Execution Plan

```

Componentes independentes permanecem válidos.

----------

# Incremental Compilation Flow

O fluxo oficial é:

```text
Source Change
      │
      ▼
Metadata Update
      │
      ▼
Dependency Graph
      │
      ▼
Invalidation
      │
      ▼
Recompilation
      │
      ▼
Updated Execution Plan

```

----------

# Artifact Reuse

Execution Artifacts não afetados devem ser reutilizados.

```text
Artifact A

Valid

↓

Reuse

```

Somente Artifacts inválidos são reconstruídos.

----------

# Execution Plan Update

Execution Plans também participam da compilação incremental.

```text
Artifact Updated

↓

Execution Plan Updated

```

Não existe reconstrução completa quando apenas parte do plano foi modificada.

----------

# Metadata Integration

O Metadata Model também é atualizado incrementalmente.

```text
Type Updated

↓

Type Metadata Updated

```

Os demais metadados permanecem reutilizados.

----------

# Validation Integration

O Validation Engine executa apenas para os componentes afetados.

```text
Updated Metadata

↓

Validation

↓

Diagnostics

```

Não há revalidação completa da aplicação.

----------

# Source Generator Integration

O Source Generator participa da compilação incremental.

```text
Updated Artifact

↓

Generated Source

↓

Assembly

```

Somente arquivos afetados são regenerados.

----------

# Compiler Diagnostics Integration

Apenas Diagnostics relacionados aos componentes recompilados são atualizados.

Diagnostics válidos permanecem reutilizados.

----------

# Dependency Tracking

O Compiler rastreia dependências entre:

-   tipos;
    
-   Profiles;
    
-   Mapping Artifacts;
    
-   Materialization Artifacts;
    
-   SQL Artifacts;
    
-   Providers;
    
-   Execution Plans.
    

Esse rastreamento determina o impacto de cada alteração.

----------

# Native AOT Compatibility

Incremental Compilation ocorre exclusivamente durante a compilação.

Nenhum mecanismo adicional é necessário durante o Runtime.

----------

# Performance Goals

O Incremental Compiler deve:

-   minimizar recompilações;
    
-   reutilizar Metadata;
    
-   reutilizar Execution Artifacts;
    
-   reduzir tempo de Build;
    
-   reduzir geração de código desnecessária;
    
-   permitir paralelização da recompilação.
    

----------

# Design Rules

-   Toda recompilação é baseada no Dependency Graph.
    
-   Apenas componentes afetados são recompilados.
    
-   Execution Artifacts válidos são reutilizados.
    
-   Execution Plans são atualizados incrementalmente.
    
-   Metadata é reutilizado sempre que possível.
    
-   O Runtime permanece completamente independente desse mecanismo.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir um Dependency Graph oficial;
    
-   alterações invalidarem apenas componentes dependentes;
    
-   Execution Artifacts puderem ser reutilizados;
    
-   Execution Plans forem recompilados apenas quando necessário;
    
-   o Source Generator suportar geração incremental;
    
-   o tempo de compilação reduzir significativamente em alterações localizadas.
    

----------

# Architecture Summary

Incremental Compilation estabelece um modelo de compilação inteligente baseado em um grafo de dependências.

Ao identificar exatamente quais componentes foram impactados por uma alteração, o FlowMapper V2 recompila apenas os Artifacts e Execution Plans necessários, reutilizando todo o restante da compilação. Essa abordagem reduz drasticamente o tempo de Build, melhora a escalabilidade da plataforma e complementa a arquitetura orientada à compilação iniciada com o Metadata Model, os Execution Artifacts e os Execution Plans.

---

# SPEC-205 — SQL Compiler

## Status

Implemented

----------

# Purpose

Definir a arquitetura oficial do **SQL Compiler** do FlowMapper V2.

O SQL Compiler é responsável por transformar definições de consultas e comandos em **SQL Execution Artifacts**, eliminando interpretação durante o Runtime.

Todo SQL utilizado pela plataforma deve ser previamente analisado, validado e compilado antes da execução.

----------

# Motivation

Tradicionalmente, ORMs constroem consultas SQL durante a execução da aplicação.

Essa abordagem introduz:

-   processamento em Runtime;
    
-   validações tardias;
    
-   geração repetitiva de comandos;
    
-   maior consumo de CPU.
    

O FlowMapper V2 adota um modelo diferente.

Todo SQL é compilado antecipadamente.

O Runtime apenas executa Artifacts previamente produzidos.

----------

# Goals

A arquitetura deve:

-   eliminar geração de SQL durante o Runtime;
    
-   validar consultas durante a compilação;
    
-   reutilizar Execution Artifacts;
    
-   reduzir Startup;
    
-   minimizar alocações;
    
-   permitir otimizações específicas por Provider;
    
-   suportar Native AOT.
    

----------

# Non Goals

Esta SPEC não define:

-   Providers;
    
-   Materialization;
    
-   Object Mapping;
    
-   Runtime Pipeline.
    

Ela define exclusivamente a compilação de SQL.

----------

# Architecture

```text
Query Definition
       │
       ▼
SQL Compiler
       │
       ▼
SQL Execution Artifact
       │
       ▼
Runtime
       │
       ▼
Provider

```

Toda geração ocorre durante a compilação.

----------

# Responsibilities

O SQL Compiler é responsável por:

-   analisar consultas;
    
-   validar parâmetros;
    
-   resolver tipos;
    
-   gerar SQL específico do Provider;
    
-   produzir Delegates de execução;
    
-   gerar SQL Execution Artifacts.
    

Nenhuma dessas operações ocorre durante o Runtime.

----------

# Compilation Flow

O fluxo oficial é:

```text
Query Definition
       │
       ▼
Syntax Analysis
       │
       ▼
Validation
       │
       ▼
SQL Generation
       │
       ▼
Execution Artifact

```

Cada etapa possui responsabilidade única.

----------

# SQL Execution Artifact

O Compiler produz um Artifact contendo todas as informações necessárias.

```text
SQL Execution Artifact
│
├── SQL Command
├── Parameter Metadata
├── Result Metadata
├── Materialization Artifact
├── Execution Delegate
└── Provider Metadata

```

O Runtime executa apenas o Delegate principal.

----------

# Query Definition

Uma consulta representa uma definição abstrata.

Exemplo:

```text
Query

↓

Execution Artifact

```

O Runtime nunca interpreta a definição original.

----------

# SQL Generation

A geração do SQL ocorre durante a compilação.

Fluxo:

```text
Query Definition

↓

Provider Dialect

↓

SQL Command

```

O SQL gerado torna-se parte do Artifact.

----------

# Parameter Binding

Todos os parâmetros são resolvidos antecipadamente.

```text
Parameter

↓

Parameter Metadata

↓

Execution

```

Nenhuma descoberta dinâmica ocorre durante o Runtime.

----------

# Result Mapping

Todo resultado está associado a um Materialization Artifact.

```text
SQL Result

↓

Materialization Artifact

↓

Object

```

A materialização reutiliza a infraestrutura oficial.

----------

# Provider Integration

Cada Provider participa da compilação.

Exemplo:

```text
Query

↓

PostgreSQL Compiler

↓

PostgreSQL SQL

```

Outro exemplo:

```text
Query

↓

SqlServer Compiler

↓

T-SQL

```

Cada Provider produz seu próprio Artifact.

----------

# Dialect Support

O SQL Compiler deve permitir Dialects independentes.

Exemplo:

```text
Dialect
├── SQL Server
├── PostgreSQL
├── Oracle
├── MySQL
└── SQLite

```

Cada Dialect permanece isolado.

----------

# Validation

Durante a compilação podem ser validados:

-   parâmetros inexistentes;
    
-   tipos incompatíveis;
    
-   comandos inválidos;
    
-   cláusulas incompatíveis;
    
-   recursos não suportados pelo Provider.
    

Todos os erros pertencem ao Compiler.

----------

# Compiler Integration

O SQL Compiler faz parte do Compiler do FlowMapper.

```text
Profiles

↓

Compiler

↓

SQL Compiler

↓

Execution Artifact

```

Todo SQL é produzido antes da execução.

----------

# Runtime Integration

O Runtime executa apenas:

```text
SQL Execution Artifact

↓

Execution Delegate

↓

Provider

```

Nenhuma geração de SQL ocorre durante a execução.

----------

# Diagnostics Integration

Durante a compilação podem ser registrados:

-   SQL gerado;
    
-   parâmetros;
    
-   otimizações aplicadas;
    
-   Dialect utilizado;
    
-   diagnósticos.
    

Essas informações pertencem ao Compiler.

----------

# Source Generator Integration

O Source Generator poderá gerar automaticamente:

-   SQL Execution Artifacts;
    
-   Parameter Metadata;
    
-   Provider Metadata;
    
-   Execution Delegates.
    

Todo o código é produzido durante o Build.

----------

# Native AOT Compatibility

O SQL Compiler deve produzir Artifacts compatíveis com:

-   Native AOT;
    
-   Linker Trimming;
    
-   Source Generation.
    

Reflection durante o Runtime é proibida.

----------

# Performance Goals

O SQL Compiler deve:

-   gerar SQL apenas uma vez;
    
-   reutilizar Artifacts;
    
-   eliminar geração dinâmica;
    
-   minimizar alocações;
    
-   reduzir custo de execução.
    

----------

# Design Rules

-   Todo SQL passa pelo SQL Compiler.
    
-   Apenas o Compiler produz SQL Execution Artifacts.
    
-   O Runtime nunca gera SQL.
    
-   Cada Provider possui seu próprio Dialect.
    
-   Materialization reutiliza a infraestrutura oficial.
    
-   Reflection durante o Runtime é proibida.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir um SQL Compiler oficial;
    
-   consultas produzirem SQL Execution Artifacts;
    
-   parâmetros forem resolvidos durante a compilação;
    
-   cada Provider puder gerar SQL específico;
    
-   o Runtime executar apenas Execution Delegates;
    
-   toda a arquitetura permanecer compatível com Native AOT.
    

----------

# Architecture Summary

O SQL Compiler transforma consultas em SQL Execution Artifacts completamente compilados, eliminando geração dinâmica durante o Runtime.

Ao centralizar análise, validação, geração de SQL e resolução de parâmetros no processo de compilação, o FlowMapper V2 adota a mesma filosofia aplicada ao Object Mapping e à Materialization, oferecendo uma arquitetura consistente, previsível e preparada para alto desempenho, geração de código e compatibilidade com Native AOT.

----------

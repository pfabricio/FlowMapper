# SPEC-04: `ForPath()`

## Objetivo

Permite mapear propriedades aninhadas (deep path) no `MappingExpression`, similar ao `ForPath` do AutoMapper:

```csharp
CreateMap<UsuarioDto, Usuario>()
    .ForPath(d => d.Perfil.PerfilID, opt => opt.MapFrom(s => s.PerfilId));
```

Em vez de precisar criar um `CreateMap` separado para `Perfil`.

## Referências

### Como o FlowMapper lida com nested atualmente

O `NestedFlow` representa um mapeamento entre tipos complexos:

```csharp
// NestedFlow.cs
public class NestedFlow
{
    public string ParentProperty { get; set; }        // "Perfil"
    public Flow ChildFlow { get; set; } = new();      // Flow de Perfil → Perfil
    public MappingStrategy Strategy { get; set; }
}
```

O `FlowBuilder.BuildCore()` detecta automaticamente nested quando uma propriedade source é um tipo complexo e a destination também:

```csharp
// FlowBuilder.cs (existente)
if (IsComplexType(sp.Type) && IsComplexType(dp.Type)
    && sp.Type is INamedTypeSymbol srcNested
    && dp.Type is INamedTypeSymbol dstNested)
{
    // Cria NestedFlow recursivamente
    var childFlow = Build(srcNested, dstNested, visited, cache);
    flow.NestedFlows.Add(new NestedFlow { ParentProperty = sp.Name, ChildFlow = childFlow });
}
```

### Limitação atual

Para mapear `UsuarioDto.PerfilId` → `Usuario.Perfil.PerfilID`, o usuário hoje precisaria:

```csharp
// Opção A: flatten (se EnableFlatten = true e Perfil.PerfilID → PerfilID)
CreateMap<UsuarioDto, Usuario>(); // automático se PerfilID existir em Usuario

// Opção B: ForMember + nested manual
CreateMap<UsuarioDto, Usuario>()
    .ForMember(d => d.Perfil, opt => opt.MapFrom(s => new Perfil { PerfilID = s.PerfilId }));
```

Nenhuma das duas é ideal. `ForPath()` resolve diretamente.

## Comportamento

`ForPath()` aceita uma expressão com **múltiplos níveis** (ex: `d => d.Perfil.PerfilID`) e extrai o path completo. O source generator então gera código que:

```csharp
// Código gerado quando ForPath(d => d.Perfil.PerfilID, ...) é usado
target.Perfil ??= new Perfil();
target.Perfil.PerfilID = source.PerfilId;
```

## Implementação

### `MappingExpression.cs` — novo método

```csharp
public class MappingExpression<TSource, TDestination>
{
    // ... métodos existentes ...

    /// <summary>
    /// Configura o mapeamento para uma propriedade aninhada (deep path).
    /// Ex: .ForPath(d => d.Perfil.PerfilID, opt => opt.MapFrom(s => s.PerfilId))
    /// </summary>
    public MappingExpression<TSource, TDestination> ForPath(
        Expression<Func<TDestination, object?>> destPath,
        Action<PathMemberOptions> options)
    {
        if (destPath.Body is MemberExpression memberExpr)
        {
            var pathSegments = ExtractPathSegments(memberExpr);
            var opts = new PathMemberOptions();
            options(opts);

            ExplicitMappings.Add(new ExplicitMapping
            {
                DestinationProperty = string.Join(".", pathSegments),
                SourceProperty = opts.SourceProperty ?? pathSegments.Last(),
                IsPathMapping = true,
                PathSegments = pathSegments,
                MapFromExpression = opts.SourceExpression
            });
        }
        return this;
    }

    private static List<string> ExtractPathSegments(MemberExpression expr)
    {
        var segments = new List<string>();
        var current = expr;
        while (current != null)
        {
            segments.Add(current.Member.Name);
            current = current.Expression as MemberExpression;
        }
        segments.Reverse();
        return segments;
    }
}

public class PathMemberOptions
{
    public string? SourceProperty { get; set; }
    public string? SourceExpression { get; set; }

    public void MapFrom(string sourceProperty)
    {
        SourceProperty = sourceProperty;
    }

    public void MapFrom(LambdaExpression expression)
    {
        SourceExpression = expression.Body.ToString();
    }
}
```

### `ExplicitMapping.cs` — novos campos

```csharp
public class ExplicitMapping
{
    public string SourceProperty { get; set; } = string.Empty;
    public string DestinationProperty { get; set; } = string.Empty;
    public bool IsIgnored { get; set; }
    public bool IsPathMapping { get; set; }        // NOVO
    public List<string> PathSegments { get; set; } = new(); // NOVO
    public string? MapFromExpression { get; set; }
}
```

### `MapperDefinitionFactory.cs` — extrair path do perfil

```csharp
// Dentro de CreateFromProfile(), no switch "ForMember":
case "ForPath":  // NOVO
    if (call.Args.Count >= 2)
    {
        var destPath = ExtractPathFromLambda(call.Args[0]);
        if (destPath == null) continue;

        var memberConfig = call.Args[1];
        var mapFromExpr = ExtractMapFromExpression(memberConfig);
        explicitMappings.Add(new ExplicitMapping
        {
            DestinationProperty = string.Join(".", destPath),
            SourceProperty = destPath.Last(),
            IsPathMapping = true,
            PathSegments = destPath,
            MapFromExpression = mapFromExpr
        });
    }
    break;
```

### `FlowBuilder.cs` — aplicar path mapping

```csharp
// Dentro de ApplyExplicitMappings()
foreach (var explicitMapping in candidate.ExplicitMappings)
{
    if (explicitMapping.IsPathMapping)
    {
        // Path mapping: gera NestedFlow ou PropertyFlow com path
        // Ex: Perfil.PerfilID → flow.NestedFlows.Add(nested) onde nested tem PerfilID
        // Se já existe NestedFlow para "Perfil", adiciona PerfilID como propriedade filha
        // Se não existe, cria NestedFlow para Perfil
        ApplyPathMapping(flow, explicitMapping, sourceType, destType);
    }
}
```

### `PropertyWriter.cs` — gerar código para path

```csharp
// NOVO: dentro de PropertyWriter.Write()
if (prop.IsPathMapping)
{
    // Gera código aninhado
    // "Perfil" → 1 segmento de profundidade: sem aninhamento extra
    // "Perfil.PerfilID" → 2 segmentos: target.Perfil ??= new(); target.Perfil.PerfilID = ...
    var path = prop.PathSegments;
    if (path.Count == 1)
    {
        // Path direto (equivalente a ForMember)
        sb.AppendLine($"        target.{path[0]} = source.{prop.SourceProperty};");
    }
    else
    {
        // Path aninhado (2+ segmentos)
        for (int i = 0; i < path.Count - 1; i++)
        {
            var prefix = string.Join(".", path.Take(i + 1));
            sb.AppendLine($"        target.{prefix} ??= new {GetNestedType(path[i])}();");
        }
        sb.AppendLine($"        target.{string.Join(".", path)} = source.{prop.SourceProperty};");
    }
}
```

## Exemplo completo

```csharp
// Profile
CreateMap<UsuarioDto, Usuario>()
    .ForPath(d => d.Perfil.PerfilID, opt => opt.MapFrom(s => s.PerfilId))
    .ForPath(d => d.Perfil.Nome, opt => opt.MapFrom(s => s.PerfilNome));

// Código gerado:
// public Usuario Map(UsuarioDto source)
// {
//     var target = new Usuario();
//     target.Perfil ??= new Perfil();
//     target.Perfil.PerfilID = source.PerfilId;
//     target.Perfil.Nome = source.PerfilNome;
//     return target;
// }
```

## Casos de borda

| Path | Comportamento |
|------|---------------|
| `d => d.Perfil.PerfilID` | 2 segmentos: gera `target.Perfil ??= new(); target.Perfil.PerfilID = ...` |
| `d => d.Endereco.Cidade.Nome` | 3 segmentos: gera `target.Endereco ??= new(); target.Endereco.Cidade ??= new(); target.Endereco.Cidade.Nome = ...` |
| `d => d.Nome` (1 segmento) | Equivalente a `ForMember` |
| Path sem `MapFrom` | Usa `SourceProperty = PathSegments.Last()` (mesmo nome) |

## Validação (Source Generator)

Novo diagnóstico:

| Código | Severidade | Descrição |
|--------|-----------|-----------|
| FM0016 | Error | Path mapping target type não encontrado no assembly |
| FM0017 | Error | Propriedade intermediária do path não tem setter público |

## Critérios de aceitação

1. `ForPath(d => d.Perfil.PerfilID, opt => opt.MapFrom(s => s.PerfilId))` gera código que cria `Perfil` se null e atribui `PerfilID`
2. Path com 3+ níveis funciona recursivamente
3. Combinado com `ReverseMap()` (SPEC-05): inverte o path corretamente
4. Path com tipo aninhado que não existe lança FM0016 em compile-time
5. Path com propriedade sem setter lança FM0017 em compile-time

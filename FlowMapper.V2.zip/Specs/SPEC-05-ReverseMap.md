# SPEC-05: `ReverseMap()`

## Objetivo

Criar automaticamente o mapeamento inverso quando `CreateMap<A, B>()` é definido:

```csharp
CreateMap<Usuario, UsuarioDto>()
    .ForMember(d => d.NomeCompleto, opt => opt.MapFrom(s => $"{s.Nome} ({s.Email})"))
    .ReverseMap();
```

Equivalente a declarar manualmente:
```csharp
CreateMap<Usuario, UsuarioDto>()
    .ForMember(d => d.NomeCompleto, opt => opt.MapFrom(s => $"{s.Nome} ({s.Email})"));
CreateMap<UsuarioDto, Usuario>();  // gerado automaticamente
```

## Referências

### Como AutoMapper implementa

No AutoMapper, `ReverseMap()` cria uma configuração reversa onde:
- Propriedades com mesmo nome → mapeamento direto (já funciona)
- `ForMember` com `MapFrom` → invertido como `ForMember` no destino oposto
- `Ignore` → invertido como `Ignore`
- `ForPath` → invertido como `ForMember` ou `ForPath`

### Estado atual do FlowMapper

`MappingExpression<TSource, TDestination>` atualmente não tem `ReverseMap()`. Não há nenhum mecanismo de mapeamento reverso automático.

## Comportamento

Quando `ReverseMap()` é chamado:

1. O source generator cria uma segunda `MapperDefinition` com source/destination invertidos
2. Aplica regras de reversão nas configurações explícitas
3. Gera dois mappers: `AtoBMapper` e `BtoAMapper`

### Regras de reversão

| Configuração original | Reversão |
|-----------------------|----------|
| Propriedades com mesmo nome (match automático) | Mantidas (match automático funciona nos dois sentidos) |
| `ForMember(d => d.X, opt => opt.MapFrom(s => s.Y))` | Gera `ForMember(d => d.Y, opt => opt.MapFrom(s => s.X))` |
| `ForMember(d => d.X, opt => opt.Ignore())` | Gera `ForMember(d => d.X, opt => opt.Ignore())` |
| `ForPath(d => d.A.B, opt => opt.MapFrom(s => s.C))` | Gera `ForMember(d => d.C, opt => opt.MapFrom(s => s.A.B))` |
| `AfterMap((s, d) => ...)` | **Não** é invertido (operation mapping não é reversível) |
| `ConstructUsing(s => ...)` | **Não** é invertido |
| `UseConstructor()` | Mantido (se aplicável ao tipo reverso) |
| `DisableFlatten()` | Mantido |
| `Ignore(d => d.X)` | Mantido |

## Implementação

### `MappingExpression.cs` — novo método

```csharp
public class MappingExpression<TSource, TDestination>
{
    // ... métodos existentes ...

    /// <summary>
    /// Cria automaticamente o mapeamento reverso (TDestination → TSource).
    /// Chamado pelo ProfileDefinition no construtor.
    /// </summary>
    public MappingExpression<TSource, TDestination> ReverseMap()
    {
        ReverseMapped = true;
        return this;
    }

    /// <summary>
    /// Indica que este mapeamento deve ser revertido.
    /// </summary>
    internal bool ReverseMapped { get; private set; }
}
```

### `ProfileDefinition.cs` — expor ReverseMap

```csharp
public class ProfileDefinition
{
    // método CreateMap existente...
    
    // ReverseMap é chamado na fluent API, nada muda no ProfileDefinition
}
```

### `MapperDefinitionFactory.cs` — gerar definição reversa

```csharp
// Dentro de CreateFromProfile(), ao processar CreateMap:
if (expression.ReverseMapped)
{
    // Cria MapperDefinition invertido
    var reverseDef = new MapperDefinition
    {
        SourceType = original.DestinationType,
        DestinationType = original.SourceType,
        MapperType = original.MapperType,
        Attribute = original.Attribute,
        ProfileName = original.ProfileName,
        ProfilePolicy = ReversePolicy(original.ProfilePolicy),
        MapperName = $"{original.DestinationType.Name}To{original.SourceType.Name}Mapper"
    };

    // Reverte propriedades (match automático não precisa ser adicionado)
    foreach (var mapping in original.ExplicitMappings)
    {
        if (mapping.IsIgnored)
        {
            reverseDef.IgnoredProperties.Add(mapping.SourceProperty);
            continue;
        }

        if (mapping.IsPathMapping)
        {
            // Inverte: ForPath(d => d.A.B) → ForMember(d => d.SourceProp)
            reverseDef.ExplicitMappings.Add(new ExplicitMappingInfo
            {
                SourceProperty = string.Join(".", mapping.PathSegments),
                DestinationProperty = mapping.DestinationProperty,
            });
            continue;
        }

        // ForMember normal: inverte source ↔ destination
        reverseDef.ExplicitMappings.Add(new ExplicitMappingInfo
        {
            SourceProperty = mapping.DestinationProperty,
            DestinationProperty = mapping.SourceProperty,
            MapFromExpression = mapping.MapFromExpression != null
                ? InvertExpression(mapping.MapFromExpression)
                : null
        });
    }

    // Adiciona à lista de candidatos
    candidates.Add(reverseDef);
}
```

### `FlowBuilder.cs` — aplicar regras reversas no build

O `FlowBuilder.Build()` já funciona para qualquer par de tipos. Como a `MapperDefinition` reversa tem SourceType/DestinationType invertidos, o builder trata como um mapeamento novo:

```csharp
// FlowBuilder.Build() SEMPRE faz:
// 1. Match de propriedades por nome
// 2. Resolve nested types
// 3. Aplica flatten
// 4. Aplica constructor binding
// 5. Aplica explicit mappings (ForMember, Ignore)

// Para o mapper reverso, as propriedades com mesmo nome serão
// automaticamente mapeadas. As explicit mappings (ForMember revertido)
// serão aplicadas via ApplyExplicitMappings().
```

### `FlowCodeGenerator.cs` — gerar ambos os mappers

O `FlowModel` contém uma `List<Flow>`. Cada flow gera uma classe separada:

```csharp
public static string Generate(FlowModel model)
{
    var sb = new StringBuilder();
    
    foreach (var flow in model.Flows)
    {
        // Gera uma classe para cada flow
        // flow.SourceType → flow.DestinationType
        
        // Nome da classe: model.MapperName
        // Se tem 2 flows (direto + reverso), o nome do flow reverso
        // será algo como "UsuarioDtoToUsuarioMapper"
    }
}
```

## Exemplo de código gerado

```csharp
// Mapper direto (original)
public partial class UsuarioToUsuarioDtoMapper : IMapper<Usuario, UsuarioDto>
{
    public UsuarioDto Map(Usuario source)
    {
        var target = new UsuarioDto();
        target.Id = source.Id;
        target.NomeCompleto = $"{source.Nome} ({source.Email})";
        return target;
    }
}

// Mapper reverso (gerado automaticamente)
public partial class UsuarioDtoToUsuarioMapper : IMapper<UsuarioDto, Usuario>
{
    public Usuario Map(UsuarioDto source)
    {
        var target = new Usuario();
        target.Id = source.Id;
        target.Nome = source.Nome;  // NomeCompleto → Nome: match automático falha,
                                      // então não mapeia (depende da regra de negócio)
        return target;
    }
}
```

> Nota: Expressões como `$"{Nome} ({Email})"` NÃO são reversíveis automaticamente. O `ReverseMap` não tenta reverter expressões. Propriedades com `MapFrom` por expressão são ignoradas no reverso, pois a lógica de transformação não é determinística ao contrário.

## `ReversePolicy()`

```csharp
private static MappingPolicy? ReversePolicy(MappingPolicy? original)
{
    if (original == null) return null;
    return new MappingPolicy
    {
        Strictness = original.Strictness,
        EnableFlatten = original.EnableFlatten,
        PreferConstructor = original.PreferConstructor
    };
}
```

## Casos de borda

| Cenário | Comportamento |
|---------|---------------|
| `ReverseMap()` sem `ForMember` | Gera mapper reverso apenas com match automático |
| `ReverseMap()` após `ForMember` com expressão | Expressão **não** é invertida; propriedade é ignorada no reverso |
| `ReverseMap()` após `Ignore` | Propriedade ignorada nos dois sentidos |
| `ReverseMap()` após `ForPath` | Path é invertido como `ForMember` no destino oposto |
| Dois `CreateMap` + `ReverseMap` para o mesmo par | Source generator detecta duplicidade e gera FM0018 (Warning) |
| Tipo reverso não tem os mesmos match automático | Propriedades sem match são ignoradas (sem erro) |

## Validação (Source Generator)

| Código | Severidade | Descrição |
|--------|-----------|-----------|
| FM0018 | Warning | ReverseMap duplicado para o mesmo par de tipos |

## Critérios de aceitação

1. `CreateMap<A, B>().ReverseMap()` gera `IMapper<B, A>` sem declarar `CreateMap<B, A>()` manualmente
2. Propriedades com mesmo nome são mapeadas automaticamente no reverso
3. `ForMember` com `MapFrom` simples (propriedade → propriedade) é invertido corretamente
4. `ForMember` com expressão é ignorado no reverso sem erro
5. `Ignore` é aplicado nos dois sentidos
6. `ForPath` é invertido como `ForMember`
7. Nome do mapper gerado é `BToAMapper`
8. Ambos os mappers são registrados no DI pelo `AddFlowMapper()`

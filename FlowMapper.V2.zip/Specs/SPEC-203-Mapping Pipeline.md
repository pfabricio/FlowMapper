# SPEC-203 — Mapping Pipeline

## Status

Implemented

----------

# Purpose

Definir a arquitetura oficial do **Mapping Pipeline** do FlowMapper V2.

O Mapping Pipeline representa a sequência de operações responsável por transformar um objeto de origem em um objeto de destino.

Todo o Pipeline é construído durante a compilação e armazenado em um Mapping Artifact.

Durante a execução, o Runtime apenas invoca o Delegate previamente gerado.

----------

# Motivation

Object Mapping é o principal recurso da plataforma.

Para garantir desempenho previsível e compatibilidade com Native AOT, nenhuma decisão deve ser tomada durante o Runtime.

Toda configuração deve ser convertida em um Pipeline compilado.

----------

# Goals

A arquitetura deve:

-   eliminar interpretação durante o Runtime;
    
-   eliminar Reflection;
    
-   suportar geração de código;
    
-   permitir composição de etapas;
    
-   reutilizar Delegates;
    
-   minimizar alocações;
    
-   manter compatibilidade com Native AOT.
    

----------

# Non Goals

Esta SPEC não define:

-   Materialization Pipeline;
    
-   SQL Compiler;
    
-   Providers;
    
-   Serialization.
    

Ela define exclusivamente o Pipeline de Object Mapping.

----------

# Architecture

```text
Source Object
      │
      ▼
Mapping Artifact
      │
      ▼
Compiled Mapping Pipeline
      │
      ▼
Destination Object

```

Todo o Pipeline é produzido pelo Compiler.

----------

# Responsibilities

O Mapping Pipeline é responsável por:

-   criar ou reutilizar o objeto de destino;
    
-   executar BeforeMap;
    
-   resolver membros;
    
-   aplicar conversões;
    
-   executar Resolvers;
    
-   executar ForPath;
    
-   executar Nested Mapping;
    
-   executar Flatten Mapping;
    
-   executar AfterMap.
    

Nenhuma dessas decisões ocorre durante o Runtime.

----------

# Mapping Flow

O fluxo oficial é:

```text
Source
   │
   ▼
BeforeMap
   │
   ▼
Create Destination
   │
   ▼
Member Mapping
   │
   ▼
Nested Mapping
   │
   ▼
Flatten Mapping
   │
   ▼
ForPath
   │
   ▼
AfterMap
   │
   ▼
Destination

```

Cada etapa possui responsabilidade única.

----------

# Mapping Artifact

O Compiler produz um Mapping Artifact contendo todas as etapas compiladas.

```text
Mapping Artifact
│
├── BeforeMap Delegate
├── Constructor Delegate
├── Member Delegates
├── Nested Delegates
├── Flatten Delegates
├── ForPath Delegates
├── AfterMap Delegate
└── Mapping Delegate

```

O Runtime executa apenas o Mapping Delegate.

----------

# BeforeMap

BeforeMap representa a primeira etapa do Pipeline.

```text
Source
      │
      ▼
BeforeMap

```

Pode ser utilizado para:

-   preparação;
    
-   normalização;
    
-   inicialização de contexto.
    

Sua posição é fixa no Pipeline.

----------

# Destination Creation

A criação do objeto ocorre através de um Delegate previamente compilado.

```text
Destination Type

↓

Constructor Delegate

↓

Object

```

Nenhuma resolução dinâmica ocorre durante a execução.

----------

# Member Mapping

Cada membro possui um Delegate específico.

```text
Source Member

↓

Mapping Delegate

↓

Destination Member

```

Todos os Delegates são produzidos durante a compilação.

----------

# Ignore

Membros marcados como Ignore não geram etapas no Pipeline.

```text
Ignored Member

↓

No Generated Delegate

```

O Runtime não realiza verificações para membros ignorados.

----------

# Value Converters

Conversores fazem parte do Pipeline.

```text
Source Value

↓

Converter Delegate

↓

Destination Value

```

Todos os Converters são resolvidos durante a compilação.

----------

# Custom Resolvers

Resolvers também são compilados.

```text
Source

↓

Resolver Delegate

↓

Destination Value

```

Nenhuma resolução dinâmica ocorre durante a execução.

----------

# Nested Mapping

Objetos complexos utilizam Mapping Artifacts compostos.

```text
Order

├── Customer Artifact

├── Address Artifact

└── Payment Artifact

```

Cada objeto mantém seu próprio Pipeline.

----------

# Flatten Mapping

Flatten utiliza Delegates previamente gerados.

```text
Customer.Address.City

↓

City

```

O caminho completo é resolvido durante a compilação.

----------

# ForPath

ForPath representa mapeamentos para caminhos específicos.

```text
Destination.Address.City

↓

Delegate

```

Todo o caminho é previamente resolvido.

----------

# AfterMap

AfterMap representa a última etapa do Pipeline.

```text
Destination

↓

AfterMap

↓

Completed Object

```

Pode realizar ajustes finais antes da conclusão do mapeamento.

----------

# Reverse Mapping

Reverse Mapping produz um Pipeline independente.

```text
Destination

↓

Reverse Mapping Artifact

↓

Source

```

Os dois Pipelines permanecem completamente independentes.

----------

# Compiler Integration

O Compiler é responsável por:

-   analisar Profiles;
    
-   validar configurações;
    
-   gerar Delegates;
    
-   produzir Mapping Artifacts.
    

Nenhuma dessas operações ocorre durante o Runtime.

----------

# Runtime Integration

O Runtime executa apenas:

```text
Mapping Artifact

↓

Mapping Delegate

↓

Destination Object

```

Nenhuma etapa adicional é executada.

----------

# Diagnostics Integration

Durante a compilação podem ser gerados diagnósticos relacionados a:

-   membros incompatíveis;
    
-   tipos incompatíveis;
    
-   conversões inválidas;
    
-   caminhos inexistentes;
    
-   conflitos de configuração.
    

Todos pertencem ao Compiler.

----------

# Source Generator Integration

O Source Generator poderá gerar automaticamente:

-   Mapping Delegates;
    
-   Constructor Delegates;
    
-   Member Delegates;
    
-   Nested Delegates;
    
-   Flatten Delegates;
    
-   Mapping Artifacts.
    

Todo o código é produzido durante o Build.

----------

# Native AOT Compatibility

O Mapping Pipeline deve ser totalmente compatível com:

-   Native AOT;
    
-   Linker Trimming;
    
-   Source Generation.
    

Reflection durante o Runtime é proibida.

----------

# Performance Goals

O Pipeline deve:

-   executar apenas Delegates compilados;
    
-   evitar Reflection;
    
-   minimizar alocações;
    
-   reutilizar Artifacts;
    
-   reduzir o Startup da aplicação;
    
-   oferecer desempenho previsível.
    

----------

# Design Rules

-   O Compiler produz o Mapping Artifact.
    
-   O Runtime apenas executa o Mapping Delegate.
    
-   Todo o Pipeline é compilado.
    
-   Cada etapa possui responsabilidade única.
    
-   BeforeMap e AfterMap possuem posições fixas.
    
-   Ignore elimina etapas do Pipeline.
    
-   Reflection nunca é utilizada durante o Runtime.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir um Mapping Artifact oficial;
    
-   todo o Pipeline for compilado;
    
-   BeforeMap e AfterMap forem executados através de Delegates;
    
-   Nested, Flatten e ForPath utilizarem Artifacts compilados;
    
-   o Runtime executar apenas o Mapping Delegate;
    
-   a arquitetura permanecer totalmente compatível com Native AOT.
    

----------

# Architecture Summary

O Mapping Pipeline estabelece um modelo de execução totalmente compilado para Object Mapping no FlowMapper V2.

Ao converter Profiles em Mapping Artifacts imutáveis e compostos por Delegates especializados, a plataforma elimina interpretação durante o Runtime, reduz o custo de execução e fornece um pipeline previsível, reutilizável e preparado para Source Generators e Native AOT.

----------

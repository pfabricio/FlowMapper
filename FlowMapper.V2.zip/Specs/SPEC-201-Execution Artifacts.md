# SPEC-201 — Execution Artifacts

## Status

Implemented

----------

# Purpose

Definir a arquitetura oficial dos **Execution Artifacts** do FlowMapper V2.

Execution Artifacts representam o resultado final produzido pelo Compiler e constituem a única entrada consumida pelo Runtime durante a execução.

Toda análise, validação, resolução de tipos, construção de metadados e geração de código devem ocorrer durante a compilação. O Runtime é responsável apenas por executar Artifacts previamente compilados.

----------

# Motivation

Bibliotecas tradicionais de Object Mapping normalmente interpretam configurações durante a execução.

Mesmo quando utilizam cache, ainda existe um Runtime responsável por resolver metadados, localizar configurações e decidir como executar um mapeamento.

O FlowMapper V2 adota uma arquitetura diferente.

Toda configuração é transformada em Artifacts imutáveis durante a compilação.

O Runtime nunca interpreta Profiles.

O Runtime nunca analisa tipos.

O Runtime apenas executa Artifacts.

----------

# Goals

A arquitetura deve:

-   eliminar interpretação durante o Runtime;
    
-   centralizar toda a saída do Compiler;
    
-   reduzir Startup;
    
-   minimizar consumo de memória;
    
-   permitir geração incremental;
    
-   suportar Native AOT;
    
-   servir como contrato oficial entre Compiler e Runtime.
    

----------

# Non Goals

Esta SPEC não define:

-   Source Generator;
    
-   SQL Compiler;
    
-   Materialization Pipeline;
    
-   Provider Model;
    
-   Runtime Pipeline.
    

Esses componentes apenas produzem ou consomem Execution Artifacts.

----------

# Architecture

```text
Profiles
      │
      ▼
Compiler
      │
      ▼
Execution Artifacts
      │
 ┌────┼────────────────────────────────────┐
 ▼            ▼               ▼            ▼
Mapping      SQL       Materialization  Runtime

```

Execution Artifacts representam a fronteira arquitetural entre compilação e execução.

----------

# Responsibilities

Os Execution Artifacts são responsáveis por armazenar todas as informações necessárias para execução.

Eles nunca executam:

-   análise;
    
-   validação;
    
-   descoberta de tipos;
    
-   geração de código;
    
-   Reflection.
    

São estruturas exclusivamente de leitura.

----------

# Core Abstraction

Adicionar:

```csharp
public interface IExecutionArtifact
{
    string Name { get; }

    Version Version { get; }
}

```

Todo Artifact implementa essa abstração.

----------

# Artifact Registry

Adicionar:

```csharp
public interface IExecutionArtifactRegistry
{
    IReadOnlyCollection<IExecutionArtifact> Artifacts { get; }
}

```

O Registry representa todos os Artifacts produzidos pelo Compiler.

----------

# Artifact Model

O Compiler poderá produzir diferentes Artifacts especializados.

```text
Execution Artifact
│
├── Mapping Artifact
├── Materialization Artifact
├── SQL Artifact
├── Constructor Artifact
├── Metadata Artifact
└── Provider Artifact

```

Cada Artifact possui uma única responsabilidade.

----------

# Mapping Artifact

Responsável pelo mapeamento entre objetos.

Pode conter:

-   Mapping Delegate;
    
-   Reverse Mapping Delegate;
    
-   BeforeMap Delegate;
    
-   AfterMap Delegate;
    
-   Flatten Metadata;
    
-   Nested Metadata;
    
-   ForPath Metadata;
    
-   Ignore Metadata;
    
-   Value Converters;
    
-   Custom Resolvers.
    

Todo o processo já está resolvido durante a compilação.

----------

# Materialization Artifact

Responsável pela materialização de objetos.

Pode conter:

-   Constructor Delegate;
    
-   Column Bindings;
    
-   Member Bindings;
    
-   Null Handling;
    
-   Value Converters;
    
-   Type Converters.
    

Nenhum acesso a metadados ocorre durante o Runtime.

----------

# SQL Artifact

Responsável pela execução SQL.

Pode conter:

-   Query Metadata;
    
-   Parameter Metadata;
    
-   Command Metadata;
    
-   Execution Delegate.
    

Todo SQL já está previamente compilado.

----------

# Constructor Artifact

Responsável pela construção de objetos.

Pode conter:

```text
Constructor

↓

Parameter Bindings

↓

Factory Delegate

```

Eliminando resolução dinâmica de construtores.

----------

# Metadata Artifact

Armazena metadados produzidos pelo Compiler.

Exemplo:

```text
Type Metadata

Property Metadata

Constructor Metadata

Relationship Metadata

Mapping Metadata

```

Essas informações podem ser utilizadas por Diagnostics e ferramentas de desenvolvimento.

----------

# Provider Artifact

Cada Provider poderá produzir Artifacts específicos.

Exemplo:

```text
SqlServer

↓

Provider Artifact

```

Outro exemplo:

```text
PostgreSQL

↓

Provider Artifact

```

O Runtime permanece independente do Provider utilizado.

----------

# Compiler Integration

O Compiler é o único componente autorizado a produzir Execution Artifacts.

Fluxo oficial:

```text
Profiles

↓

Analysis

↓

Validation

↓

Code Generation

↓

Execution Artifacts

```

Nenhum outro componente cria Artifacts.

----------

# Runtime Integration

O Runtime consome exclusivamente Artifacts.

```text
Execution Artifact

↓

Delegate

↓

Execution

```

O Runtime nunca interpreta configurações.

----------

# Immutability

Após produzidos pelo Compiler:

-   nenhuma modificação é permitida;
    
-   nenhuma informação é recalculada;
    
-   nenhuma estrutura pode ser reconstruída.
    

Todos os Artifacts são imutáveis.

----------

# Incremental Compilation

Cada Artifact pode ser recompilado individualmente.

```text
Profile A

↓

Artifact A

Profile B

↓

Artifact B

```

Uma alteração em um Profile não exige recompilar todos os demais.

----------

# Execution Lifecycle

O ciclo oficial é:

```text
Profile

↓

Compile

↓

Execution Artifact

↓

Registry

↓

Runtime

↓

Execution

```

O Runtime sempre executa Artifacts registrados.

----------

# Source Generator Integration

O Source Generator gera diretamente os Execution Artifacts.

```text
Source Generator

↓

Execution Artifacts

↓

Compiled Assembly

```

Os Artifacts passam a fazer parte da aplicação compilada.

----------

# Native AOT Compatibility

Os Execution Artifacts devem ser totalmente compatíveis com:

-   Native AOT;
    
-   Linker Trimming;
    
-   Source Generation.
    

Nenhum Artifact pode depender de Reflection.

----------

# Performance Goals

Os Execution Artifacts devem:

-   utilizar apenas estruturas imutáveis;
    
-   minimizar alocações;
    
-   utilizar Delegates previamente gerados;
    
-   eliminar consultas durante o Runtime;
    
-   reduzir o Startup da aplicação;
    
-   permitir execução previsível.
    

----------

# Design Rules

-   Apenas o Compiler cria Execution Artifacts.
    
-   Apenas o Runtime consome Execution Artifacts.
    
-   Execution Artifacts são imutáveis.
    
-   Toda informação necessária para execução pertence ao Artifact.
    
-   Reflection nunca é utilizada durante a execução.
    
-   O Runtime nunca interpreta Profiles ou configurações.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir `IExecutionArtifact`;
    
-   existir `IExecutionArtifactRegistry`;
    
-   o Compiler produzir Artifacts especializados para Mapping, SQL e Materialization;
    
-   o Runtime consumir exclusivamente Execution Artifacts;
    
-   todos os Artifacts forem imutáveis;
    
-   a arquitetura suportar compilação incremental;
    
-   a plataforma permanecer totalmente compatível com Native AOT.
    

----------

# Architecture Summary

Execution Artifacts representam o contrato oficial entre o Compiler e o Runtime do FlowMapper V2.

Ao transformar Profiles e configurações em estruturas imutáveis e prontas para execução, o FlowMapper elimina interpretação durante o Runtime, reduz custos de inicialização, melhora o desempenho e estabelece uma arquitetura orientada à compilação, preparada para Source Generators, Native AOT e evolução incremental da plataforma.

---

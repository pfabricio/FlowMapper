# SPEC-03: `.Map<TDest>()` Extension Method

## Objetivo

Permite encadear o resultado de uma query do RapidMapper com o mapping do FlowMapper numa única chamada:

```csharp
var dtos = await db.QueryAsync<Usuario>(sql, new { id }).Map<UsuarioDto>();
```

## Referências

### API atual do RapidMapper (retorna Task)

```csharp
// QueryExecutor.cs
Task<IEnumerable<T>> QueryAsync<T>(string sql, object? parameters, ExecutionOptions?, CancellationToken);

// RapidMapper.cs (facade)
public Task<IEnumerable<T>> QueryAsync<T>(...) => _queryExecutor.QueryAsync<T>(...);
```

### API atual do FlowMapper

```csharp
// IFlowMapper.cs
TDestination Map<TSource, TDestination>(TSource source);
IMapper<TSource, TDestination> GetMapper<TSource, TDestination>();
```

## Comportamento

O `.Map<TDest>()` é uma **extension method** que:
1. Aguarda a `Task` retornada pelo `QueryAsync` (ou similar)
2. Resolve o `IMapper<TSource, TDest>` do service provider
3. Mapeia cada elemento da coleção
4. Retorna `List<TDest>`

## Implementação

### `MapExtensions.cs` — localizado em `FlowMapper.DependencyInjection/Extensions/`

```csharp
using FlowMapper.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace FlowMapper.DependencyInjection;

public static class DataMapperExtensions
{
    private static IFlowMapper? _mapper;

    /// <summary>
    /// Inicializa o service provider para resolução de mappers.
    /// Chamado internamente pelo AddFlowMapper().
    /// </summary>
    internal static void Initialize(IServiceProvider serviceProvider)
    {
        _mapper = serviceProvider.GetRequiredService<IFlowMapper>();
    }

    /// <summary>
    /// Mapeia o resultado de uma query assíncrona usando o FlowMapper.
    /// </summary>
    public static async Task<List<TDest>> Map<TSource, TDest>(
        this Task<IEnumerable<TSource>> task)
    {
        var source = await task;
        return MapEnumerable<TSource, TDest>(source);
    }

    /// <summary>
    /// Mapeia query de lista explícita.
    /// </summary>
    public static async Task<List<TDest>> Map<TSource, TDest>(
        this Task<List<TSource>> task)
    {
        var source = await task;
        return MapEnumerable<TSource, TDest>(source);
    }

    /// <summary>
    /// Mapeia QuerySingleAsync — resultado único.
    /// </summary>
    public static async Task<TDest> Map<TSource, TDest>(
        this Task<TSource> task)
    {
        var source = await task;
        return _mapper!.Map<TSource, TDest>(source);
    }

    private static List<TDest> MapEnumerable<TSource, TDest>(IEnumerable<TSource> source)
    {
        var mapper = _mapper!.GetMapper<TSource, TDest>();
        return source.Select(s => mapper.Map(s)).ToList();
    }
}
```

### Inicialização no `AddFlowMapper()`

Modificar `ServiceCollectionExtensions.cs` para chamar `Initialize` após construir o provider:

```csharp
// No final de ServiceCollectionExtensions.AddFlowMapper():
services.AddSingleton(sp =>
{
    DataMapperExtensions.Initialize(sp);
    return sp;
});
```

Ou usar um `IStartupFilter` / `IConfigureContainer` dependendo do runtime (mais simples: inicialização lazy).

### Inicialização Lazy (alternativa sem `Initialize`)

```csharp
public static class DataMapperExtensions
{
    private static readonly AsyncLocal<IFlowMapper?> _mapper = new();

    internal static void SetMapper(IFlowMapper mapper) => _mapper.Value = mapper;

    public static async Task<List<TDest>> Map<TSource, TDest>(
        this Task<IEnumerable<TSource>> task)
    {
        var source = await task;
        var mapper = _mapper.Value!;
        return source.Select(s => mapper.Map<TSource, TDest>(s)).ToList();
    }
}
```

E no `FlowMapperService` (que já é scoped), registrar no construtor:

```csharp
public class FlowMapperService : IFlowMapper
{
    public FlowMapperService(IServiceProvider serviceProvider)
    {
        DataMapperExtensions.SetMapper(this);
        // ...
    }
}
```

## Overloads suportados

```csharp
// Todos os métodos de query do IRapidMapper

// Múltiplos resultados (mais comum)
Task<IEnumerable<T>> .Map<TDest>()
Task<List<T>>       .Map<TDest>()

// Resultado único
Task<T>             .Map<TDest>()     // QuerySingleAsync → MapSingle
Task<T?>            .Map<TDest>()     // QuerySingleOrDefaultAsync

// Streaming (requer materialização)
IAsyncEnumerable<T> .Map<TDest>()     // StreamAsync → Map em cada item
```

### Streaming

Para `StreamAsync` o comportamento precisa materializar:

```csharp
public static async IAsyncEnumerable<TDest> Map<TSource, TDest>(
    this IAsyncEnumerable<TSource> source)
{
    var mapper = _mapper!.GetMapper<TSource, TDest>();
    await foreach (var item in source)
    {
        yield return mapper.Map(item);
    }
}
```

## Exceções

- Se `IFlowMapper` não foi inicializado → `InvalidOperationException`: "Call AddFlowMapper() during startup before using .Map<TDest>()"
- Se `IMapper<TSource, TDest>` não foi registrado → `InvalidOperationException` do `FlowMapperService`: "No mapper registered for ..."

## Critérios de aceitação

1. `QueryAsync<Usuario>(sql).Map<UsuarioDto>()` compila e executa
2. `QuerySingleAsync<Usuario>(sql).Map<UsuarioDto>()` compila e executa
3. `StreamAsync<Usuario>(sql).Map<UsuarioDto>()` compila e executa com streaming
4. Parâmetros do `QueryAsync` são preservados (ex: `new { id }`)
5. Exceção clara se `AddFlowMapper()` não foi chamado
6. Exceção clara se profile não foi registrado para o par Usuario/UsuarioDto

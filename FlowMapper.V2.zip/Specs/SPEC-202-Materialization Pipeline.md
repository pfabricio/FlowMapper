# SPEC-202 — Materialization Pipeline

## Status

Implemented

----------

# Purpose

Definir a arquitetura oficial do **Materialization Pipeline** do FlowMapper V2.

O Materialization Pipeline é responsável por transformar dados provenientes de uma origem em instâncias de objetos.

Toda a lógica de materialização deve ser compilada antecipadamente pelo Compiler, produzindo um Materialization Artifact que será executado pelo Runtime.

----------

# Motivation

A materialização é uma das operações mais críticas da plataforma.

Ela é utilizada por:

-   SQL Mapping;
    
-   Object Mapping;
    
-   Data Providers;
    
-   File Providers;
    
-   APIs externas.
    

Para garantir previsibilidade e alto desempenho, o processo de materialização deve ser previamente compilado.

----------

# Goals

A arquitetura deve:

-   eliminar Reflection durante o Runtime;
    
-   eliminar descoberta dinâmica de membros;
    
-   permitir geração de Delegates especializados;
    
-   suportar múltiplas origens de dados;
    
-   minimizar alocações;
    
-   ser compatível com Native AOT.
    

----------

# Non Goals

Esta SPEC não define:

-   SQL Compiler;
    
-   Providers;
    
-   Object Mapping;
    
-   Serialization.
    

Ela define apenas o pipeline responsável pela materialização.

----------

# Architecture

```text
Data Source
      │
      ▼
Materialization Artifact
      │
      ▼
Materialization Delegate
      │
      ▼
Destination Object

```

Todo o pipeline é previamente produzido pelo Compiler.

----------

# Responsibilities

O Materialization Pipeline é responsável por:

-   criar a instância de destino;
    
-   resolver construtores;
    
-   mapear colunas;
    
-   converter valores;
    
-   aplicar tratamento de nulos;
    
-   preencher membros.
    

Ele nunca realiza descoberta dinâmica durante a execução.

----------

# Materialization Flow

O fluxo oficial é:

```text
Source
      │
      ▼
Read Values
      │
      ▼
Convert Values
      │
      ▼
Create Instance
      │
      ▼
Bind Members
      │
      ▼
Complete Object

```

Cada etapa possui responsabilidade única.

----------

# Materialization Artifact

O Compiler produz um Artifact contendo todas as informações necessárias.

```text
Materialization Artifact
│
├── Constructor Delegate
├── Column Bindings
├── Member Bindings
├── Value Converters
├── Null Handlers
└── Materialization Delegate

```

O Runtime executa apenas o Delegate principal.

----------

# Constructor Resolution

A escolha do construtor ocorre durante a compilação.

```text
Destination Type

↓

Constructor Analysis

↓

Constructor Delegate

```

Nenhuma resolução ocorre durante o Runtime.

----------

# Column Binding

Cada coluna é associada previamente ao membro correspondente.

```text
Column "Id"

↓

Property Id

```

```text
Column "Name"

↓

Property Name

```

Todos os Bindings são gerados pelo Compiler.

----------

# Value Conversion

Conversões de tipo também são resolvidas antecipadamente.

Exemplos:

```text
int

↓

long

```

```text
string

↓

Guid

```

```text
DateTime

↓

DateOnly

```

Nenhuma conversão utiliza Reflection.

----------

# Null Handling

O tratamento de valores nulos faz parte do Artifact.

Fluxo:

```text
Read Value

↓

Is Null?

↓

Default Value

↓

Assignment

```

As regras são definidas durante a compilação.

----------

# Member Binding

Após a criação do objeto, os membros são preenchidos.

```text
Object

↓

Property Delegate

↓

Assignment

```

Cada membro possui um Delegate específico.

----------

# Nested Materialization

Objetos complexos podem utilizar Materialization Artifacts compostos.

```text
Order

├── Customer Artifact

├── Address Artifact

└── Items Artifact

```

Cada objeto mantém seu próprio pipeline.

----------

# Collection Materialization

Coleções utilizam Artifacts especializados.

```text
Rows

↓

Item Materializer

↓

Collection Builder

↓

List<T>

```

O mecanismo é independente da origem dos dados.

----------

# Provider Independence

O Pipeline é independente do Provider.

Exemplos:

```text
IDataReader

↓

Materialization Artifact

```

```text
Csv Reader

↓

Materialization Artifact

```

```text
Json Reader

↓

Materialization Artifact

```

Todos utilizam exatamente o mesmo modelo.

----------

# Compiler Integration

O Compiler é responsável por:

-   analisar tipos;
    
-   resolver construtores;
    
-   gerar Delegates;
    
-   produzir Materialization Artifacts.
    

Nenhum desses passos ocorre durante a execução.

----------

# Runtime Integration

O Runtime executa apenas:

```text
Materialization Artifact

↓

Materialization Delegate

↓

Object

```

Nenhuma etapa adicional é realizada.

----------

# Diagnostics Integration

Durante a compilação podem ser gerados diagnósticos relacionados a:

-   construtores inválidos;
    
-   colunas ausentes;
    
-   membros incompatíveis;
    
-   conversões inválidas;
    
-   tipos não suportados.
    

Todos pertencem ao Compiler.

----------

# Source Generator Integration

O Source Generator poderá gerar automaticamente:

-   Constructor Delegates;
    
-   Property Delegates;
    
-   Column Bindings;
    
-   Materialization Delegates;
    
-   Materialization Artifacts.
    

Todo o código é gerado em Build Time.

----------

# Native AOT Compatibility

O Materialization Pipeline deve ser totalmente compatível com:

-   Native AOT;
    
-   Linker Trimming;
    
-   Source Generation.
    

Reflection durante o Runtime é proibida.

----------

# Performance Goals

O Pipeline deve:

-   evitar Reflection;
    
-   evitar alocações desnecessárias;
    
-   utilizar apenas Delegates gerados;
    
-   minimizar acesso indireto;
    
-   permitir execução previsível.
    

----------

# Design Rules

-   O Compiler produz o Materialization Artifact.
    
-   O Runtime apenas executa o Materialization Delegate.
    
-   Toda resolução ocorre durante a compilação.
    
-   Cada etapa possui responsabilidade única.
    
-   O Pipeline é independente da origem dos dados.
    
-   Reflection nunca é utilizada durante o Runtime.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir um Materialization Artifact oficial;
    
-   construtores forem resolvidos durante a compilação;
    
-   Column Bindings forem previamente gerados;
    
-   conversões utilizarem Delegates compilados;
    
-   o Runtime executar apenas o Materialization Delegate;
    
-   a arquitetura permanecer compatível com Native AOT.
    

----------

# Architecture Summary

O Materialization Pipeline estabelece um modelo unificado para criação de objetos no FlowMapper V2.

Ao transformar todo o processo de materialização em um Artifact compilado, a plataforma elimina interpretação durante o Runtime, reduz o custo de execução e permite que diferentes Providers reutilizem exatamente a mesma infraestrutura, mantendo alto desempenho, previsibilidade e compatibilidade com Native AOT.

----------

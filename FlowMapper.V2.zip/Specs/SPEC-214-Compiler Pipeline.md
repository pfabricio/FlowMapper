# SPEC-214 — Compiler Pipeline

## Status

Draft

----------

# Purpose

Definir a arquitetura oficial do **Compiler Pipeline** do FlowMapper V2.

O Compiler Pipeline representa o fluxo completo de compilação da plataforma, organizando todas as etapas em uma sequência de **Stages** independentes, previsíveis e extensíveis.

Cada Stage possui uma responsabilidade única, recebe um conjunto bem definido de entradas e produz uma saída consumida pelo próximo Stage.

----------

# Motivation

O processo de compilação do FlowMapper envolve diversos componentes especializados.

Exemplos:

-   Metadata Builder;
    
-   Validation Engine;
    
-   Optimization Engine;
    
-   Mapping Compiler;
    
-   SQL Compiler;
    
-   Materialization Compiler;
    
-   Source Generator;
    
-   Execution Plan Builder.
    

Sem uma arquitetura formal, o acoplamento entre esses componentes tende a crescer.

O Compiler Pipeline estabelece um fluxo único e padronizado para toda a compilação.

----------

# Goals

A arquitetura deve:

-   organizar a compilação em Stages;
    
-   garantir responsabilidade única por Stage;
    
-   permitir extensibilidade;
    
-   facilitar paralelização;
    
-   suportar compilação incremental;
    
-   manter previsibilidade.
    

----------

# Non Goals

Esta SPEC não define:

-   regras de validação;
    
-   otimizações específicas;
    
-   geração de código;
    
-   Runtime.
    

Ela define apenas o pipeline responsável por coordenar a compilação.

----------

# Architecture

```text
Application
      │
      ▼
Metadata Builder
      │
      ▼
Validation Stage
      │
      ▼
Optimization Stage
      │
      ▼
Compilation Stage
      │
      ▼
Source Generation Stage
      │
      ▼
Execution Plan Stage
      │
      ▼
Compilation Result

```

Cada Stage executa apenas uma responsabilidade.

----------

# Responsibilities

O Compiler Pipeline é responsável por:

-   coordenar a compilação;
    
-   executar os Stages na ordem correta;
    
-   compartilhar o contexto da compilação;
    
-   interromper o fluxo em caso de erro crítico;
    
-   produzir o resultado final da compilação.
    

Ele nunca executa operações de Runtime.

----------

# Core Abstraction

Adicionar:

```csharp
public interface ICompilerStage
{
    string Name { get; }

    CompilerStageResult Execute(CompilerContext context);
}

```

Todo Stage implementa essa interface.

----------

# Compiler Context

Todos os Stages compartilham um único contexto.

```text
Compiler Context
│
├── Metadata Model
├── Diagnostics
├── Compilation Cache
├── Dependency Graph
├── Plugin Registry
├── Generated Sources
└── Execution Plans

```

Nenhum Stage cria um novo contexto.

----------

# Stage Lifecycle

O ciclo oficial é:

```text
Receive Context

↓

Execute

↓

Update Context

↓

Return Result

```

Cada Stage atualiza apenas as informações sob sua responsabilidade.

----------

# Metadata Stage

Responsável por:

-   construir o Metadata Model;
    
-   atualizar metadados incrementais;
    
-   alimentar o restante do Pipeline.
    

Saída:

```text
Metadata Model

```

----------

# Validation Stage

Responsável por:

-   executar todas as regras de validação;
    
-   produzir Diagnostics;
    
-   interromper a compilação quando necessário.
    

Entrada:

```text
Metadata Model

```

Saída:

```text
Validation Result

```

----------

# Optimization Stage

Responsável por:

-   aplicar Optimization Passes;
    
-   produzir um Metadata Model otimizado.
    

Entrada:

```text
Metadata Model

```

Saída:

```text
Optimized Metadata Model

```

----------

# Compilation Stage

Responsável por produzir os Artifacts da plataforma.

Inclui:

-   Mapping Compiler;
    
-   Materialization Compiler;
    
-   SQL Compiler;
    
-   Provider Compiler.
    

Saída:

```text
Execution Artifacts

```

----------

# Source Generation Stage

Responsável por gerar código.

Exemplos:

-   Delegates;
    
-   Registries;
    
-   Factories;
    
-   Bootstrap;
    
-   Providers.
    

Saída:

```text
Generated Sources

```

----------

# Execution Plan Stage

Responsável por montar os Execution Plans.

Fluxo:

```text
Execution Artifacts

↓

Execution Plans

```

Os planos representam a saída oficial da compilação.

----------

# Compilation Result

Ao término do Pipeline, é produzido um único resultado.

```text
Compilation Result
│
├── Execution Plans
├── Generated Sources
├── Diagnostics
├── Statistics
└── Metadata

```

Esse resultado representa a compilação completa.

----------

# Error Handling

Caso um Stage produza erros críticos:

```text
Stage

↓

Diagnostics

↓

Pipeline Stop

```

Os Stages seguintes não são executados.

----------

# Incremental Compilation Integration

O Pipeline trabalha em conjunto com o Dependency Graph e o Compilation Cache.

Cada Stage executa apenas quando existirem componentes inválidos.

Stages cujos resultados permanecem válidos podem ser completamente ignorados.

----------

# Plugin Integration

Plugins podem registrar novos Stages.

Exemplo:

```text
Validation Stage

↓

Custom Stage

↓

Optimization Stage

```

A ordem de execução é controlada pelo Pipeline.

----------

# Diagnostics Integration

Todos os Stages produzem Diagnostics através da infraestrutura oficial.

Nenhum Stage registra mensagens diretamente.

----------

# Performance Monitoring

O Pipeline deve registrar métricas como:

-   tempo por Stage;
    
-   quantidade de Artifacts produzidos;
    
-   cache hits;
    
-   cache misses;
    
-   recompilações;
    
-   código gerado.
    

Essas informações auxiliam na análise de desempenho da compilação.

----------

# Native AOT Compatibility

O Compiler Pipeline faz parte exclusivamente do processo de compilação.

Nenhum Stage adiciona dependências ao Runtime.

----------

# Performance Goals

O Compiler Pipeline deve:

-   minimizar dependências entre Stages;
    
-   permitir paralelização quando possível;
    
-   reutilizar resultados válidos;
    
-   reduzir tempo de Build;
    
-   simplificar a implementação dos Compilers.
    

----------

# Design Rules

-   Todo Stage implementa `ICompilerStage`.
    
-   Todos os Stages compartilham um único Compiler Context.
    
-   Cada Stage possui responsabilidade única.
    
-   O Pipeline interrompe a execução em caso de erros críticos.
    
-   Plugins podem adicionar novos Stages.
    
-   O Runtime nunca participa do Compiler Pipeline.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir `ICompilerStage`;
    
-   existir um Compiler Context compartilhado;
    
-   todos os componentes do Compiler estiverem organizados em Stages;
    
-   Plugins puderem registrar novos Stages;
    
-   o Pipeline suportar Compilation Cache e Incremental Compilation;
    
-   o resultado final da compilação for representado por um único `CompilationResult`.
    

----------

# Architecture Summary

O Compiler Pipeline organiza todo o processo de compilação do FlowMapper V2 em uma sequência estruturada de Stages independentes e especializados.

Ao definir contratos claros entre as etapas, compartilhar um único contexto de compilação e integrar mecanismos como Validation, Optimization, Compilation Cache, Incremental Compilation e Plugins, o FlowMapper estabelece uma arquitetura semelhante à de compiladores modernos, tornando o processo previsível, extensível e altamente eficiente.

----------

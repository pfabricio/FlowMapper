# SPEC-209 — Compiler Diagnostics

## Status

Implemented

----------

# Purpose

Definir a arquitetura oficial do **Compiler Diagnostics** do FlowMapper V2.

Compiler Diagnostics representa o sistema unificado de comunicação entre os componentes do Compiler e o desenvolvedor.

Todos os erros, avisos, informações e sugestões produzidos durante a compilação devem ser representados por Diagnostics padronizados.

----------

# Motivation

Durante a compilação diversos componentes analisam a aplicação.

Exemplos:

-   Metadata Builder;
    
-   Validation Engine;
    
-   Mapping Compiler;
    
-   SQL Compiler;
    
-   Materialization Compiler;
    
-   Source Generator.
    

Cada componente pode identificar problemas ou oportunidades de melhoria.

Um modelo unificado de Diagnostics torna essas informações consistentes, previsíveis e facilmente consumidas por IDEs, ferramentas de Build e desenvolvedores.

----------

# Goals

A arquitetura deve:

-   centralizar todos os Diagnostics;
    
-   padronizar mensagens;
    
-   fornecer códigos únicos;
    
-   definir níveis de severidade;
    
-   permitir extensibilidade;
    
-   facilitar integração com IDEs;
    
-   melhorar a experiência do desenvolvedor.
    

----------

# Non Goals

Esta SPEC não define:

-   Validation Rules;
    
-   Metadata Model;
    
-   Source Generator;
    
-   Runtime Diagnostics.
    

Ela define exclusivamente os Diagnostics produzidos durante a compilação.

----------

# Architecture

```text
Compiler Components
        │
        ▼
Compiler Diagnostics
        │
        ▼
Build Output
        │
        ├── IDE
        ├── CLI
        ├── Logs
        └── CI/CD

```

Todos os componentes produzem Diagnostics através da mesma infraestrutura.

----------

# Responsibilities

Compiler Diagnostics é responsável por:

-   registrar erros;
    
-   registrar avisos;
    
-   registrar informações;
    
-   registrar sugestões;
    
-   fornecer localização;
    
-   fornecer códigos padronizados.
    

Ele nunca executa validações.

----------

# Diagnostic Flow

O fluxo oficial é:

```text
Compiler Component
        │
        ▼
Diagnostic
        │
        ▼
Diagnostic Collection
        │
        ▼
Build Output

```

Todos os Diagnostics seguem exatamente o mesmo modelo.

----------

# Core Abstraction

Adicionar:

```csharp
public interface IDiagnostic
{
    string Code { get; }

    DiagnosticSeverity Severity { get; }

    string Message { get; }
}

```

Todo Diagnostic implementa essa abstração.

----------

# Severity Levels

Os níveis oficiais são:

```text
Error

Warning

Information

Suggestion

```

Cada severidade possui significado bem definido.

----------

# Error

Representa uma falha que impede a geração dos Execution Artifacts.

Exemplos:

-   tipo inexistente;
    
-   construtor inválido;
    
-   Mapping incompatível;
    
-   SQL inválido.
    

A compilação deve ser interrompida.

----------

# Warning

Representa situações válidas, porém potencialmente problemáticas.

Exemplos:

-   Mapping redundante;
    
-   conversão implícita;
    
-   membro não utilizado;
    
-   configuração desnecessária.
    

A compilação pode continuar.

----------

# Information

Representa informações úteis ao desenvolvedor.

Exemplos:

-   Artifact gerado;
    
-   otimização aplicada;
    
-   Provider selecionado;
    
-   geração incremental utilizada.
    

----------

# Suggestion

Representa oportunidades de melhoria.

Exemplos:

-   utilizar Flatten Mapping;
    
-   utilizar ReverseMap;
    
-   remover configuração redundante;
    
-   substituir configuração obsoleta.
    

Sugestões nunca alteram o resultado da compilação.

----------

# Diagnostic Codes

Cada Diagnostic possui um código único.

Formato oficial:

```text
FM0001
FM0002
FM0003
...

```

Os códigos são permanentes entre versões compatíveis.

----------

# Diagnostic Categories

Os Diagnostics podem ser organizados por categoria.

```text
Metadata

Mapping

Materialization

SQL

Providers

Configuration

Source Generator

Performance

```

A categoria facilita filtragem e organização.

----------

# Diagnostic Location

Sempre que possível, um Diagnostic deve informar sua origem.

Exemplos:

-   Profile;
    
-   Type;
    
-   Property;
    
-   Constructor;
    
-   Mapping;
    
-   SQL Definition.
    

Essa informação permite integração com IDEs.

----------

# Diagnostic Collection

Todos os Diagnostics pertencem a uma única coleção.

```text
Compiler

↓

Diagnostic Collection

↓

Build Output

```

Os componentes nunca mantêm coleções próprias.

----------

# Compiler Integration

Todos os componentes do Compiler utilizam exclusivamente Compiler Diagnostics.

```text
Metadata Builder

↓

Validation Engine

↓

Mapping Compiler

↓

SQL Compiler

↓

Materialization Compiler

↓

Source Generator

↓

Compiler Diagnostics

```

----------

# Validation Integration

O Validation Engine produz Diagnostics utilizando exclusivamente a infraestrutura oficial.

Nenhuma mensagem é emitida diretamente.

----------

# Source Generator Integration

O Source Generator também utiliza Compiler Diagnostics.

Exemplos:

-   geração ignorada;
    
-   código incompatível;
    
-   otimizações aplicadas.
    

----------

# IDE Integration

A arquitetura deve permitir integração com:

-   Visual Studio;
    
-   Visual Studio Code;
    
-   Rider;
    
-   ferramentas de Build.
    

Cada Diagnostic deve conter informações suficientes para navegação até sua origem.

----------

# CI/CD Integration

Durante processos automatizados de Build, os Diagnostics podem ser exportados para:

-   logs;
    
-   relatórios;
    
-   pipelines de integração contínua.
    

Isso permite bloquear Builds quando existirem erros críticos.

----------

# Extensibility

Novos módulos podem registrar Diagnostics adicionais.

Exemplos:

-   Providers;
    
-   Plugins;
    
-   Extensions.
    

Todos seguem o mesmo modelo.

----------

# Native AOT Compatibility

Compiler Diagnostics fazem parte exclusivamente do processo de compilação.

Nenhum componente depende de Reflection durante o Runtime.

----------

# Performance Goals

Compiler Diagnostics deve:

-   minimizar alocações;
    
-   reutilizar estruturas internas;
    
-   permitir agregação eficiente;
    
-   evitar duplicação de mensagens.
    

----------

# Design Rules

-   Todo Diagnostic implementa `IDiagnostic`.
    
-   Todos os componentes utilizam a mesma infraestrutura.
    
-   Cada Diagnostic possui código único.
    
-   A severidade determina o comportamento da compilação.
    
-   Errors interrompem a geração de Execution Artifacts.
    
-   Warnings, Information e Suggestions nunca impedem a compilação.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir `IDiagnostic`;
    
-   existir um sistema unificado de Compiler Diagnostics;
    
-   todos os componentes do Compiler utilizarem essa infraestrutura;
    
-   Diagnostics possuírem códigos padronizados;
    
-   Diagnostics informarem severidade e localização;
    
-   IDEs e ferramentas de Build puderem consumir essas informações de forma consistente.
    

----------

# Architecture Summary

Compiler Diagnostics estabelece um protocolo único de comunicação entre o Compiler e o desenvolvedor.

Ao centralizar erros, avisos, informações e sugestões em um modelo padronizado, o FlowMapper V2 fornece uma experiência consistente durante a compilação, simplifica a integração com IDEs e ferramentas de Build e reforça a filosofia da plataforma de detectar problemas o mais cedo possível, antes que qualquer Execution Artifact seja produzido.

----------

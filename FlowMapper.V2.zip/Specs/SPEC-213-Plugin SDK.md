# SPEC-213 — Plugin SDK

## Status

Draft

----------

# Purpose

Definir a arquitetura oficial do **Plugin SDK** do FlowMapper V2.

O Plugin SDK estabelece o modelo oficial para extensão da plataforma, permitindo adicionar funcionalidades ao Compiler, Runtime e demais componentes sem modificar o Core.

Plugins são cidadãos de primeira classe da arquitetura e representam o principal mecanismo de extensibilidade do FlowMapper.

----------

# Motivation

Embora Providers permitam integrar novas tecnologias, eles representam apenas uma categoria de extensão.

A plataforma também deve permitir que desenvolvedores adicionem:

-   novos Compilers;
    
-   novas regras de validação;
    
-   novos passes de otimização;
    
-   novos Providers;
    
-   novos Source Generators;
    
-   novos serviços de Runtime;
    
-   novos diagnósticos.
    

Tudo isso deve ocorrer através de uma infraestrutura única.

----------

# Goals

A arquitetura deve:

-   permitir extensão da plataforma;
    
-   manter baixo acoplamento;
    
-   preservar o isolamento entre Plugins;
    
-   permitir descoberta durante a compilação;
    
-   suportar Source Generation;
    
-   manter compatibilidade com Native AOT.
    

----------

# Non Goals

Esta SPEC não define:

-   Module System;
    
-   Dependency Injection;
    
-   Providers;
    
-   Runtime.
    

Ela define apenas o SDK oficial para criação de Plugins.

----------

# Architecture

```text
Plugin
   │
   ▼
Plugin Manifest
   │
   ▼
Plugin Loader
   │
   ▼
Plugin Registry
   │
 ┌─┼────────────────────────────────────────────────────────────────┐
 ▼            ▼           ▼         ▼        ▼        ▼             ▼
Compiler Validation Optimization Provider Runtime Diagnostics Source Generator

```

Todo Plugin é registrado através do Plugin Registry.

----------

# Responsibilities

Um Plugin pode:

-   registrar novos serviços;
    
-   registrar Providers;
    
-   adicionar Validation Rules;
    
-   adicionar Optimization Passes;
    
-   registrar Source Generators;
    
-   produzir Diagnostics;
    
-   participar da compilação;
    
-   participar do Runtime.
    

Plugins nunca modificam diretamente o Core.

----------

# Core Abstraction

Adicionar:

```csharp
public interface IFlowMapperPlugin
{
    string Name { get; }

    Version Version { get; }

    void Configure(IPluginBuilder builder);
}

```

Todo Plugin implementa essa interface.

----------

# Plugin Manifest

Cada Plugin possui um Manifest declarando seus metadados.

Exemplo:

```text
Plugin Manifest
│
├── Name
├── Version
├── Author
├── Description
├── Dependencies
└── Capabilities

```

O Manifest é utilizado durante o Bootstrap da compilação.

----------

# Plugin Categories

Os Plugins podem atuar em diferentes áreas.

```text
Plugin
│
├── Compiler Plugin
├── Provider Plugin
├── Runtime Plugin
├── Validation Plugin
├── Optimization Plugin
├── Diagnostics Plugin
└── Source Generator Plugin

```

Um Plugin pode pertencer a mais de uma categoria.

----------

# Plugin Lifecycle

O ciclo de vida oficial é:

```text
Discovery
    │
    ▼
Load
    │
    ▼
Configure
    │
    ▼
Register
    │
    ▼
Ready

```

Após o estado **Ready**, o Plugin está disponível para uso.

----------

# Plugin Registry

Todos os Plugins registrados pertencem ao Registry.

```text
Plugin Registry
│
├── Providers
├── Validators
├── Optimizers
├── Generators
├── Runtime Services
└── Diagnostics

```

O Registry centraliza todas as extensões da plataforma.

----------

# Compiler Integration

Plugins podem participar da compilação adicionando:

-   novos Compilers;
    
-   etapas adicionais;
    
-   regras de geração;
    
-   analisadores;
    
-   transformações.
    

A ordem de execução é controlada pelo Compiler Pipeline.

----------

# Validation Integration

Plugins podem registrar validadores adicionais.

```text
Metadata Model

↓

Plugin Validator

↓

Diagnostics

```

As regras permanecem isoladas do Core.

----------

# Optimization Integration

Plugins podem registrar novos Optimization Passes.

```text
Metadata Model

↓

Plugin Optimization Pass

↓

Optimized Metadata

```

Cada otimização é executada dentro do Optimization Engine.

----------

# Provider Integration

Providers são implementados como Plugins especializados.

```text
Plugin

↓

Provider

↓

Runtime

```

Todos os Providers utilizam a mesma infraestrutura.

----------

# Runtime Integration

Plugins podem registrar:

-   serviços;
    
-   comportamentos;
    
-   componentes auxiliares;
    
-   mecanismos de execução.
    

O Runtime continua consumindo apenas contratos públicos.

----------

# Diagnostics Integration

Plugins podem produzir Diagnostics próprios.

Todos os Diagnostics utilizam a infraestrutura oficial do Compiler Diagnostics.

----------

# Source Generator Integration

Plugins podem adicionar novos Source Generators.

```text
Metadata

↓

Plugin Generator

↓

Generated Source

```

A geração permanece integrada ao Compiler.

----------

# Dependency Management

Plugins podem declarar dependências.

```text
Plugin A

↓

Plugin B

```

O Plugin Loader deve garantir que todas as dependências sejam resolvidas antes da inicialização.

----------

# Isolation

Cada Plugin permanece isolado.

Um Plugin nunca acessa diretamente o estado interno de outro Plugin.

Toda comunicação ocorre através de contratos públicos.

----------

# Versioning

Cada Plugin possui sua própria versão.

A compatibilidade é validada durante o carregamento.

Plugins incompatíveis não devem ser registrados.

----------

# Native AOT Compatibility

O Plugin SDK deve ser compatível com:

-   Native AOT;
    
-   Linker Trimming;
    
-   Source Generation.
    

A descoberta de Plugins deve utilizar metadados gerados durante a compilação, evitando Reflection durante o Runtime.

----------

# Performance Goals

O Plugin SDK deve:

-   minimizar custo de carregamento;
    
-   evitar Reflection durante o Runtime;
    
-   permitir carregamento incremental;
    
-   reutilizar registros previamente compilados;
    
-   manter baixo impacto na inicialização.
    

----------

# Design Rules

-   Todo Plugin implementa `IFlowMapperPlugin`.
    
-   Providers são um tipo especializado de Plugin.
    
-   Plugins nunca modificam diretamente o Core.
    
-   Toda comunicação ocorre através de contratos públicos.
    
-   O Plugin Registry centraliza todas as extensões.
    
-   A descoberta e o registro devem ser compatíveis com Native AOT.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir `IFlowMapperPlugin`;
    
-   existir um Plugin Registry oficial;
    
-   Plugins puderem estender Compiler, Runtime e Providers;
    
-   Providers utilizarem a infraestrutura de Plugins;
    
-   Plugins puderem registrar validadores, otimizações e Source Generators;
    
-   toda a arquitetura permanecer compatível com Native AOT.
    

----------

# Architecture Summary

O Plugin SDK estabelece o modelo oficial de extensibilidade do FlowMapper V2.

Ao tratar Plugins como componentes de primeira classe da arquitetura, a plataforma unifica Providers, validadores, otimizações, Source Generators e extensões de Runtime sob uma única infraestrutura. Essa abordagem mantém o Core pequeno e estável, facilita a evolução da plataforma e permite que novas capacidades sejam adicionadas sem alterar os componentes centrais, preservando os princípios de modularidade, baixo acoplamento e compilação antecipada.

----------

# SPEC-06: Samples e Testes

## Objetivo

Criar exemplos e testes que demonstrem e validem os três modos de uso do FlowMapper unificado, além dos novos recursos (`ForPath`, `ReverseMap`, `.Map<TDest>()`).

## Samples

### Sample 01: BasicMapping

Demonstra o uso combinado mais simples:

```csharp
// Models
public class Usuario
{
    public int Id { get; set; }
    public string Nome { get; set; } = "";
    public string Email { get; set; } = "";
}

public class UsuarioDto
{
    public int Id { get; set; }
    public string NomeCompleto { get; set; } = "";
}

// Profile
class AppProfile : ProfileDefinition
{
    public AppProfile()
    {
        CreateMap<Usuario, UsuarioDto>()
            .ForMember(d => d.NomeCompleto, opt => opt.MapFrom(s => $"{s.Nome} ({s.Email})"));
    }
}

// Program.cs
builder.Services.AddFlowMapper(builder =>
{
    builder.AddProfile<AppProfile>();
});

var mapper = serviceProvider.GetRequiredService<IFlowMapper>();
var dto = mapper.Map<Usuario, UsuarioDto>(usuario);
Console.WriteLine(dto.NomeCompleto);
```

### Sample 02: DataAccess

```csharp
// Program.cs
builder.Services.AddFlowMapper(builder =>
{
    builder.AddProvider<SqlServerProvider>();
    builder.AddDialect<SqlServerDialect>();
});

var db = serviceProvider.GetRequiredService<IRapidMapper>();
var users = await db.QueryAsync<Usuario>("SELECT Id, Nome, Email FROM Usuarios");
```

### Sample 03: Combined (Map Extension)

```csharp
class AppProfile : ProfileDefinition
{
    public AppProfile()
    {
        CreateMap<Usuario, UsuarioDto>()
            .ForMember(d => d.NomeCompleto, opt => opt.MapFrom(s => $"{s.Nome} ({s.Email})"));
    }
}

// Repository
public class UsuarioRepository
{
    private readonly IRapidMapper _db;

    public UsuarioRepository(IRapidMapper db) => _db = db;

    public async Task<List<UsuarioDto>> GetAllAsync()
    {
        const string sql = "SELECT Id, Nome, Email FROM Usuarios";
        return await _db.QueryAsync<Usuario>(sql).Map<UsuarioDto>();
    }
}
```

### Sample 04: ForPath + ReverseMap

```csharp
public class Usuario
{
    public int Id { get; set; }
    public string Nome { get; set; } = "";
    public Perfil Perfil { get; set; } = new();
}

public class Perfil
{
    public int PerfilID { get; set; }
    public string Nome { get; set; } = "";
}

public class UsuarioDto
{
    public int Id { get; set; }
    public string Nome { get; set; } = "";
    public int PerfilId { get; set; }
    public string PerfilNome { get; set; } = "";
}

class AppProfile : ProfileDefinition
{
    public AppProfile()
    {
        // Mapeamento: UsuarioDto (flat) → Usuario (nested)
        CreateMap<UsuarioDto, Usuario>()
            .ForPath(d => d.Perfil.PerfilID, opt => opt.MapFrom(s => s.PerfilId))
            .ForPath(d => d.Perfil.Nome, opt => opt.MapFrom(s => s.PerfilNome))
            .ReverseMap(); // Gera Usuario → UsuarioDto automaticamente
    }
}

// Uso:
var dto = mapper.Map<Usuario, UsuarioDto>(usuario);
// Com ReverseMap, mapeia Usuario.Perfil.PerfilID → PerfilId
```

### Sample 05: ConstructorBinding

```csharp
public class Usuario
{
    public int Id { get; }
    public string Nome { get; }
    public Usuario(int id, string nome)
    {
        Id = id;
        Nome = nome;
    }
}

class AppProfile : ProfileDefinition
{
    public AppProfile()
    {
        CreateMap<UsuarioDto, Usuario>()
            .UseConstructor(); // Usa construtor com parâmetros
    }
}
```

### Sample 06: Transaction

```csharp
await using var scope = db.CreateScope(transactional: true);

await db.ExecuteAsync(
    "INSERT INTO Pedidos (Total) VALUES (@Total)",
    new { Total = 99.90 });

await db.ExecuteAsync(
    "UPDATE Estoque SET Qtd = Qtd - 1 WHERE ProdutoId = @Id",
    new { Id = 1 });

// Commit automático no fim do using
// Rollback automático se exceção
```

## Testes

### Projetos de teste

```
tests/
├── FlowMapper.UnitTests/                    # Testes unitários
│   ├── Abstractions/
│   ├── Core/
│   ├── Data/
│   └── Mapping/
├── FlowMapper.Generator.Tests/              # Testes do source generator (Roslyn)
├── FlowMapper.IntegrationTests/             # Testes com banco real (SQLite in-memory)
└── FlowMapper.PerformanceTests/             # Benchmarks comparativos
```

### Casos de teste prioritários

#### `FlowMapper.UnitTests`

| Teste | O que valida |
|-------|-------------|
| `MappingExpression_ForPath_CreatesPathMapping` | `ForPath(d => d.A.B)` cria `ExplicitMapping` com `IsPathMapping = true` e `PathSegments` = ["A", "B"] |
| `MappingExpression_ReverseMap_SetsFlag` | `ReverseMap()` marca `ReverseMapped = true` |
| `ProfileDefinition_CreateDataReaderMap_AddsMapping` | `CreateDataReaderMap<T>()` adiciona entrada na lista |
| `FlowMapperOptions_DefaultValues` | Opções têm valores padrão corretos |
| `MappingOptions_DefaultSeparator` | Separador padrão é `"_"` |

#### `FlowMapper.Generator.Tests`

Usar `GeneratorTestHelper` (já existe no projeto FlowMapper) para validar código gerado.

| Teste | O que valida |
|-------|-------------|
| `ForPath_GeneratesNestedCode` | `ForPath(d => d.Perfil.PerfilID)` gera `target.Perfil ??= new(); target.Perfil.PerfilID = ...` |
| `ForPath_ThreeLevels_GeneratesNestedCode` | Path com 3+ níveis gera cascata de `??= new()` |
| `ReverseMap_GeneratesTwoMappers` | `ReverseMap()` emite dois arquivos `.g.cs` |
| `ReverseMap_InvertsSimpleForMember` | `ForMember(d => d.X, MapFrom(s => s.Y))` vira `ForMember(d => d.Y, MapFrom(s => s.X))` |
| `ReverseMap_IgnoresExpressionMapFrom` | `MapFrom` com expressão é ignorado no reverso |
| `MapExtension_ResolvesMapper` | Source generator detecta `QueryAsync<T>(SQL)` e registra mapper |
| `Combined_DataAccessAndMapping` | Profile com `CreateMap` + `CreateDataReaderMap` gera ambos |
| `NestedMapping_FlatColumns_GeneratesNestedCode` | Coluna `Perfil_PerfilID` → gera nested assignment |

#### `FlowMapper.IntegrationTests`

| Teste | O que valida |
|-------|-------------|
| `QueryAsync_MapExtension_ReturnsMappedResults` | SQL → QueryAsync → `.Map<Dto>()` retorna DTOs corretos |
| `QuerySingleAsync_MapExtension_ReturnsSingleMapped` | `QuerySingleAsync → Map` retorna um DTO |
| `StreamAsync_MapExtension_StreamsMappedResults` | `StreamAsync → Map` retorna DTOs em streaming |
| `ReverseMap_MapBothDirections` | `Map<A, B>` e `Map<B, A>` funcionam |
| `ForPath_MapNestedProperty` | `ForPath` + `Map` produz objeto com nested populado |
| `Transaction_Commit_RollsBackOnError` | Escopo transacional com rollback em exceção |
| `MultiDatabase_NamedConnections` | Conexões com nomes diferentes funcionam |

#### `FlowMapper.PerformanceTests`

| Teste | O que mede |
|-------|-----------|
| `Mapper_Throughput` | map/segundo para mapper gerado vs runtime |
| `DataAccess_QueryMapping` | Throughput de QueryAsync com mapping |
| `MapExtension_Overhead` | Overhead do `.Map<TDest>()` vs manual |
| `ForPath_OverheadNested` | Performance de nested mapping via ForPath |

## Estrutura de diretórios final

```
FlowMapperV2/
├── samples/
│   ├── BasicMapping/
│   │   ├── BasicMapping.csproj
│   │   ├── Program.cs
│   │   └── Profiles/
│   ├── DataAccess/
│   │   └── ...
│   ├── Combined/
│   │   └── ...
│   ├── ForPathAndReverse/
│   │   └── ...
│   ├── ConstructorMapping/
│   │   └── ...
│   └── Transaction/
│       └── ...
│
├── tests/
│   ├── FlowMapper.UnitTests/
│   │   ├── FlowMapper.UnitTests.csproj
│   │   ├── Abstractions/
│   │   ├── Core/
│   │   │   ├── MappingExpressionTests.cs
│   │   │   ├── ProfileDefinitionTests.cs
│   │   │   └── FlowMapperOptionsTests.cs
│   │   ├── Data/
│   │   │   ├── MappingOptionsTests.cs
│   │   │   └── ExecutionOptionsTests.cs
│   │   └── Mapping/
│   ├── FlowMapper.Generator.Tests/
│   │   ├── FlowMapper.Generator.Tests.csproj
│   │   ├── GeneratorTests.cs
│   │   └── Snapshots/
│   │       ├── ForPath_Snapshot.g.cs
│   │       ├── ReverseMap_Snapshot.g.cs
│   │       └── Combined_Snapshot.g.cs
│   ├── FlowMapper.IntegrationTests/
│   │   ├── FlowMapper.IntegrationTests.csproj
│   │   └── DataAccess/
│   │       ├── QueryExtensionTests.cs
│   │       ├── MapExtensionTests.cs
│   │       └── TransactionTests.cs
│   └── FlowMapper.PerformanceTests/
│       ├── FlowMapper.PerformanceTests.csproj
│       └── Program.cs (BenchmarkDotNet)
```

## Critérios de aceitação

1. Todos os samples compilam e executam sem erro
2. Todos os testes unitários passam
3. Testes de snapshot do generator validam código gerado exato
4. Testes de integração rodam contra SQLite in-memory
5. Benchmark mostra performance do mapper gerado vs Expressão Tree do RapidMapper
6. `dotnet test` na raiz do repositório executa todos os projetos de teste

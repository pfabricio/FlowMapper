# SPEC-212 — Compilation Cache

## Status

Draft

----------

# Purpose

Definir a arquitetura oficial do **Compilation Cache** do FlowMapper V2.

O Compilation Cache é responsável por armazenar os resultados intermediários e finais da compilação, permitindo sua reutilização em compilações incrementais e reduzindo significativamente o tempo de Build.

Seu objetivo é evitar o reprocessamento de componentes que permanecem válidos entre diferentes execuções do Compiler.

----------

# Motivation

Mesmo utilizando Incremental Compilation, determinadas etapas da compilação podem produzir resultados idênticos entre Builds consecutivos.

Reexecutar essas etapas aumenta desnecessariamente:

-   tempo de compilação;
    
-   consumo de CPU;
    
-   consumo de memória;
    
-   geração de código.
    

O Compilation Cache elimina esse trabalho repetitivo.

----------

# Goals

A arquitetura deve:

-   reutilizar resultados válidos;
    
-   reduzir tempo de Build;
    
-   reduzir recompilações;
    
-   integrar-se ao Dependency Graph;
    
-   suportar invalidação seletiva;
    
-   manter consistência entre Builds.
    

----------

# Non Goals

Esta SPEC não define:

-   Incremental Compilation;
    
-   Dependency Graph;
    
-   Metadata Builder;
    
-   Source Generator.
    

Ela define exclusivamente o mecanismo oficial de cache da compilação.

----------

# Architecture

```text
Source Changes
      │
      ▼
Dependency Graph
      │
      ▼
Compilation Cache
      │
      ├── Cache Hit
      │
      └── Cache Miss
              │
              ▼
      Compilation Pipeline
              │
              ▼
         Cache Update

```

O Cache participa de todas as etapas da compilação.

----------

# Responsibilities

O Compilation Cache é responsável por:

-   armazenar resultados intermediários;
    
-   armazenar Execution Artifacts;
    
-   armazenar Execution Plans;
    
-   reutilizar componentes válidos;
    
-   invalidar componentes obsoletos;
    
-   reduzir recompilações.
    

Ele nunca executa geração de código.

----------

# Core Abstraction

Adicionar:

```csharp
public interface ICompilationCache
{
    bool TryGet<T>(CompilationKey key, out T value);

    void Store<T>(CompilationKey key, T value);

    void Invalidate(CompilationKey key);

    void Clear();
}

```

O Cache é acessado exclusivamente através dessa abstração.

----------

# Cached Components

O Cache pode armazenar:

```text
Compilation Cache
│
├── Metadata Model
├── Validation Results
├── Optimized Metadata
├── Execution Artifacts
├── Execution Plans
├── Generated Sources
└── Diagnostics

```

Cada componente possui um ciclo de vida independente.

----------

# Cache Keys

Cada item armazenado possui uma chave única.

A chave pode considerar:

-   tipo;
    
-   Profile;
    
-   Provider;
    
-   versão;
    
-   dependências;
    
-   hash da configuração.
    

A chave identifica unicamente um resultado de compilação.

----------

# Cache Lookup

Antes de executar uma etapa, o Compiler consulta o Cache.

```text
Compilation Step
      │
      ▼
Cache Lookup
      │
 ┌────┴────┐
 │         │
Hit      Miss
 │         │
 ▼         ▼
Reuse   Execute Step

```

----------

# Cache Invalidation

A invalidação ocorre através do Dependency Graph.

```text
Type Changed
      │
      ▼
Dependency Graph
      │
      ▼
Invalidate Cache Entries

```

Apenas componentes dependentes são removidos.

----------

# Metadata Cache

O Metadata Model pode ser reutilizado quando nenhuma alteração estrutural ocorrer.

```text
Reflection

↓

Metadata Model

↓

Cache

```

Evitando nova análise de Reflection.

----------

# Validation Cache

Resultados de validação também podem ser reutilizados.

```text
Metadata

↓

Validation

↓

Cache

```

Somente metadados alterados são revalidados.

----------

# Optimization Cache

O modelo otimizado pode ser armazenado.

```text
Metadata

↓

Optimization

↓

Cache

```

Evitando repetir otimizações idênticas.

----------

# Artifact Cache

Execution Artifacts são candidatos naturais ao Cache.

```text
Mapping Artifact

↓

Cache

```

O mesmo vale para:

-   Materialization Artifacts;
    
-   SQL Artifacts;
    
-   Provider Artifacts.
    

----------

# Execution Plan Cache

Execution Plans também podem ser reutilizados.

```text
Execution Plan

↓

Cache

```

Somente planos afetados por alterações são recompilados.

----------

# Generated Source Cache

O código gerado pode ser reutilizado quando nenhuma alteração ocorrer.

```text
Source Generator

↓

Generated Source

↓

Cache

```

Reduzindo significativamente o tempo de geração.

----------

# Diagnostics Cache

Diagnostics válidos podem permanecer armazenados.

Somente componentes recompilados produzem novos Diagnostics.

----------

# Compiler Integration

Todas as etapas do Compiler consultam o Cache antes de executar.

```text
Metadata Builder

↓

Validation

↓

Optimization

↓

Compilers

↓

Source Generator

```

Cada etapa decide entre reutilizar ou recalcular seus resultados.

----------

# Incremental Compilation Integration

O Compilation Cache trabalha em conjunto com o Dependency Graph.

O Dependency Graph determina o que foi invalidado.

O Cache determina o que ainda pode ser reutilizado.

----------

# Extensibility

Novos módulos podem armazenar seus próprios resultados.

Exemplos:

-   Providers;
    
-   Plugins;
    
-   Extensions.
    

Cada módulo define suas próprias chaves de cache.

----------

# Native AOT Compatibility

O Compilation Cache faz parte exclusivamente do processo de compilação.

Nenhuma estrutura de cache é utilizada durante o Runtime.

----------

# Performance Goals

O Compilation Cache deve:

-   minimizar leituras desnecessárias;
    
-   reduzir recompilações;
    
-   reutilizar resultados intermediários;
    
-   reduzir tempo de Build;
    
-   minimizar consumo de memória.
    

----------

# Design Rules

-   Toda etapa do Compiler consulta o Cache antes de executar.
    
-   O Dependency Graph controla a invalidação.
    
-   Apenas componentes inválidos são recompilados.
    
-   O Cache nunca modifica resultados armazenados.
    
-   Todos os itens armazenados são considerados imutáveis.
    
-   O Runtime nunca utiliza o Compilation Cache.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir um `ICompilationCache`;
    
-   Metadata, Validation, Optimization, Execution Artifacts e Execution Plans puderem ser armazenados;
    
-   o Dependency Graph controlar a invalidação;
    
-   apenas componentes inválidos forem recompilados;
    
-   o Source Generator reutilizar código previamente gerado;
    
-   nenhuma estrutura de cache for utilizada durante o Runtime.
    

----------

# Architecture Summary

O Compilation Cache complementa a arquitetura incremental do FlowMapper V2 ao reutilizar resultados intermediários e finais da compilação.

Integrado ao Dependency Graph e ao Incremental Compilation, ele permite que o Compiler recalcule apenas os componentes realmente afetados por alterações, reduzindo drasticamente o tempo de Build, eliminando processamento redundante e fortalecendo a filosofia central da plataforma: **compilar uma única vez, reutilizar sempre que possível e executar apenas o necessário**.

----------

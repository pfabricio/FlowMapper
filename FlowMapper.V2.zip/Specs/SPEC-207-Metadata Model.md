# SPEC-207 — Metadata Model

## Status

Implemented

----------

# Purpose

Definir a arquitetura oficial do **Metadata Model** do FlowMapper V2.

O Metadata Model representa a abstração interna utilizada pelo Compiler para descrever tipos, membros, construtores, relacionamentos e configurações da aplicação.

Após a construção do Metadata Model, todos os componentes do Compiler passam a utilizar exclusivamente essas informações, eliminando consultas repetidas à Reflection.

----------

# Motivation

A compilação do FlowMapper depende de uma grande quantidade de informações sobre a aplicação.

Exemplos:

-   tipos;
    
-   propriedades;
    
-   campos;
    
-   construtores;
    
-   parâmetros;
    
-   atributos;
    
-   relacionamentos;
    
-   configurações de Mapping.
    

Consultar Reflection continuamente aumenta a complexidade e o custo da compilação.

O Metadata Model centraliza todas essas informações em uma representação única e independente.

----------

# Goals

A arquitetura deve:

-   centralizar todos os metadados da compilação;
    
-   eliminar consultas repetidas à Reflection;
    
-   servir como entrada para todos os Compilers;
    
-   permitir otimizações;
    
-   facilitar diagnósticos;
    
-   suportar Source Generators;
    
-   manter compatibilidade com Native AOT.
    

----------

# Non Goals

Esta SPEC não define:

-   Execution Plans;
    
-   Mapping Pipeline;
    
-   SQL Compiler;
    
-   Materialization Pipeline.
    

Ela define apenas o modelo de metadados utilizado durante a compilação.

----------

# Architecture

```text
Reflection
      │
      ▼
Metadata Builder
      │
      ▼
Metadata Model
      │
 ┌────┼────────────────────────────────────────┐
 ▼       ▼          ▼            ▼             ▼
Mapping SQL Materialization Validation Source Generator

```

Reflection é utilizada apenas para construir o Metadata Model.

----------

# Responsibilities

O Metadata Model é responsável por representar:

-   tipos;
    
-   membros;
    
-   construtores;
    
-   parâmetros;
    
-   relacionamentos;
    
-   configurações;
    
-   atributos relevantes.
    

O modelo nunca executa lógica de negócio.

----------

# Core Abstraction

Adicionar:

```csharp
public interface IMetadataModel
{
    IReadOnlyCollection<ITypeMetadata> Types { get; }
}

```

O Metadata Model representa toda a aplicação analisada.

----------

# Metadata Builder

O Metadata Builder é o único componente autorizado a construir metadados.

Fluxo:

```text
Application

↓

Reflection

↓

Metadata Builder

↓

Metadata Model

```

Após essa etapa, Reflection deixa de ser utilizada.

----------

# Type Metadata

Cada tipo analisado gera um Type Metadata.

Exemplo:

```text
Customer

↓

Type Metadata

```

Um Type Metadata pode conter:

-   nome;
    
-   namespace;
    
-   tipo base;
    
-   interfaces;
    
-   construtores;
    
-   membros.
    

----------

# Member Metadata

Cada membro possui um Metadata específico.

Exemplo:

```text
Customer.Name

↓

Member Metadata

```

Pode conter:

-   nome;
    
-   tipo;
    
-   leitura;
    
-   escrita;
    
-   acessibilidade.
    

----------

# Constructor Metadata

Cada construtor possui uma representação própria.

```text
Customer()

↓

Constructor Metadata

```

Contém:

-   parâmetros;
    
-   visibilidade;
    
-   regras de seleção.
    

----------

# Parameter Metadata

Cada parâmetro também possui metadados.

```text
Constructor

↓

Parameter Metadata

```

Essas informações são reutilizadas pelo Materialization Compiler.

----------

# Relationship Metadata

Representa relacionamentos entre tipos.

Exemplo:

```text
Order

↓

Customer

↓

Address

```

Esses relacionamentos são utilizados pelos Compilers de Mapping e Materialization.

----------

# Mapping Metadata

Representa as configurações declaradas pelo usuário.

Exemplos:

-   CreateMap;
    
-   ReverseMap;
    
-   Ignore;
    
-   ForMember;
    
-   ForPath;
    
-   Flatten;
    
-   Nested Mapping.
    

Todo Mapping é convertido em Metadata antes da compilação.

----------

# Provider Metadata

Cada Provider pode adicionar metadados específicos.

Exemplos:

```text
SqlServer Metadata

PostgreSQL Metadata

MongoDB Metadata

```

Esses metadados permanecem isolados do Core.

----------

# Metadata Immutability

Após construído:

-   nenhum Metadata pode ser alterado;
    
-   nenhuma informação pode ser recalculada;
    
-   nenhuma estrutura pode ser reconstruída.
    

Todo Metadata é imutável.

----------

# Compiler Integration

Todos os Compilers utilizam exclusivamente o Metadata Model.

```text
Metadata Model
├── Mapping Compiler
├── SQL Compiler
├── Materialization Compiler
├── Validation Engine
└── Source Generator

```

Nenhum componente consulta Reflection diretamente.

----------

# Validation Integration

O Validation Engine valida exclusivamente o Metadata Model.

Exemplos:

-   tipos incompatíveis;
    
-   membros inexistentes;
    
-   construtores inválidos;
    
-   configurações conflitantes.
    

----------

# Source Generator Integration

O Source Generator utiliza o Metadata Model como entrada.

Fluxo:

```text
Metadata Model

↓

Source Generator

↓

Generated Code

```

Toda geração parte do mesmo conjunto de metadados.

----------

# Execution Plan Integration

Execution Plans utilizam metadados produzidos pelo Compiler.

```text
Metadata Model

↓

Execution Plan

↓

Execution Artifacts

```

Nenhum metadado é reconstruído durante a execução.

----------

# Native AOT Compatibility

O Metadata Model deve ser totalmente compatível com:

-   Native AOT;
    
-   Linker Trimming;
    
-   Source Generation.
    

Reflection permanece restrita à fase de compilação.

----------

# Performance Goals

O Metadata Model deve:

-   evitar consultas repetidas à Reflection;
    
-   reutilizar metadados entre Compilers;
    
-   minimizar alocações;
    
-   permitir acesso rápido às informações;
    
-   reduzir o tempo de compilação.
    

----------

# Design Rules

-   Apenas o Metadata Builder cria metadados.
    
-   Reflection é utilizada apenas durante a construção do Metadata Model.
    
-   Todos os metadados são imutáveis.
    
-   Todos os Compilers utilizam exclusivamente o Metadata Model.
    
-   Nenhum componente consulta Reflection diretamente após a construção do modelo.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir um `IMetadataModel`;
    
-   existir um Metadata Builder oficial;
    
-   Reflection estiver restrita à construção do Metadata Model;
    
-   Mapping Compiler, SQL Compiler, Materialization Compiler, Validation Engine e Source Generator utilizarem exclusivamente o Metadata Model;
    
-   todos os metadados forem imutáveis;
    
-   a arquitetura permanecer compatível com Native AOT.
    

----------

# Architecture Summary

O Metadata Model estabelece uma representação única e imutável da aplicação durante a compilação.

Ao concentrar todas as informações estruturais em um modelo compartilhado, o FlowMapper V2 elimina consultas repetidas à Reflection, simplifica a implementação dos Compilers e fornece uma base consistente para geração de código, validação, otimizações e construção dos Execution Plans, mantendo a filosofia central da plataforma: **compilar o máximo possível e executar apenas o necessário**.

----------

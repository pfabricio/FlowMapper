# FlowMapper V2

# Source Generator V2 Specification

## Introduction

The FlowMapper Source Generator is responsible for converting mapping
definitions into highly optimized C# source code during compilation.

Unlike traditional runtime mappers, the FlowMapper generator performs
all possible analysis during compilation, minimizing runtime overhead.

The Source Generator is designed as an evolution of the current V2
implementation, preserving compatibility while expanding its capabilities.

---

# Design Goals

The Generator has the following objectives:

- Zero manual mapper implementation.
- Compile-time validation.
- Incremental generation.
- Minimal runtime reflection.
- Native support for ReverseMap.
- Native support for ForPath.
- Shared infrastructure for Object Mapping and Data Mapping.
- Fast compilation.
- Predictable generated code.

---

# Generator Architecture

The generator is composed of independent stages.

```text
Roslyn Compilation
          │
          ▼
Syntax Discovery
          │
          ▼
Semantic Analysis
          │
          ▼
Flow Model Builder
          │
          ▼
Validation
          │
          ▼
Code Generation
          │
          ▼
Generated .g.cs
```

Each stage has a single responsibility.

---

# Generator Pipeline

The generator executes the following pipeline.

## Stage 1

Discover all CreateMap() declarations.

Example:

```csharp
CreateMap<Customer, CustomerDto>();
```

---

## Stage 2

Resolve semantic information.

The generator identifies:

- source type
- destination type
- constructors
- properties
- nested members
- collection mappings
- generic arguments

---

## Stage 3

Build the internal Flow Model.

The Flow Model becomes the canonical representation of the mapping.

It is independent from Roslyn.

---

## Stage 4

Apply mapping rules.

Examples:

- Ignore
- ForMember
- ForPath
- ConstructUsing
- DisableFlatten
- ReverseMap

---

## Stage 5

Validate the mapping.

Examples:

- missing members
- invalid paths
- incompatible types
- circular mappings
- constructor ambiguity

Diagnostics are emitted during compilation.

---

## Stage 6

Generate optimized C# source.

---

# Incremental Generation

The Source Generator must use the Roslyn Incremental Generator API.

Only modified mappings are regenerated.

Benefits:

- faster compilation
- reduced memory usage
- predictable generation

---

# CreateMap Discovery

The generator discovers every invocation of:

```csharp
CreateMap<TSource, TDestination>()
```

Only valid mapping declarations become Flow Models.

---

# Flow Model

The Flow Model is the internal representation used by every generator.

Example:

```text
Customer

↓

CustomerDto

↓

Property Flows

↓

Nested Flows

↓

Generation
```

The Flow Model is never coupled to Roslyn APIs.

---

# ReverseMap Generation

ReverseMap does not generate mappings dynamically.

Instead, a second Flow Model is created.

Example:

```csharp
CreateMap<Customer, CustomerDto>()
    .ReverseMap();
```

Produces:

```text
Customer → CustomerDto

CustomerDto → Customer
```

Both mappings are generated independently.

---

# ForPath Generation

Nested member mappings are resolved during compilation.

Example:

```csharp
.ForPath(
    d => d.Address.City,
    s => s.City)
```

Generated code performs direct assignments without runtime traversal.

Example:

```csharp
destination.Address.City = source.City;
```

No reflection is required.

---

# Reflection Strategy

Reflection remains available only when generation is impossible.

Priority:

1. Generated code
2. Cached delegates
3. Reflection (fallback)

Reflection should never execute during normal generated mappings.

---

# Shared Generation Infrastructure

The generator infrastructure must be reusable.

Two mapping domains consume the same pipeline.

## Object Mapping

```text
Object

↓

Object
```

## Data Mapping

```text
DbDataReader

↓

Object
```

Both generators share:

- Flow Model
- validation
- diagnostics
- naming
- templates
- metadata

Only the final code emission differs.

---

# Generated Code Philosophy

Generated code must resemble handwritten code.

Example:

```csharp
destination.Id = source.Id;
destination.Name = source.Name;
```

No runtime abstractions should remain inside generated methods.

---

# Diagnostics

The generator emits compile-time diagnostics.

Examples:

- unmapped member
- invalid path
- unsupported conversion
- inaccessible constructor
- recursive mapping

Errors prevent generation.

Warnings generate code when possible.

---

# Performance Goals

The generator should provide:

- zero reflection for generated mappings
- minimal allocations
- predictable execution
- AOT compatibility
- Native trimming compatibility

---

# Benchmarks

The generated mapper should be benchmarked against:

- Manual Mapping
- AutoMapper
- Mapperly
- Mapster
- FlowMapper V1

Benchmark scenarios include:

- flat objects
- nested objects
- collections
- reverse mappings
- large object graphs

---

# Future Evolution

Future versions may support:

- conditional generation
- source-generated converters
- polymorphic mapping
- record optimizations
- immutable object construction
- partial generation reuse
- generated IDataReader materializers

---

# Generator Principles

The FlowMapper Generator follows five principles:

- Generate everything possible.
- Validate during compilation.
- Avoid runtime reflection.
- Produce readable generated code.
- Share infrastructure across mapping domains.

---

# SPEC-204 — Provider Architecture

## Status

Implemented

----------

# Purpose

Definir a arquitetura oficial dos **Providers** do FlowMapper V2.

Providers representam a camada responsável por integrar o FlowMapper com tecnologias externas de origem e destino de dados.

Cada Provider implementa uma tecnologia específica enquanto reutiliza a infraestrutura comum fornecida pelo Core e pelo Runtime.

----------

# Motivation

O FlowMapper foi projetado para ser independente de tecnologias.

O Runtime não deve conhecer detalhes de:

-   bancos de dados;
    
-   arquivos;
    
-   APIs;
    
-   protocolos;
    
-   formatos de dados.
    

Toda integração deve ocorrer através de Providers especializados.

----------

# Goals

A arquitetura deve:

-   isolar tecnologias externas;
    
-   reutilizar a infraestrutura do Core;
    
-   permitir novos Providers;
    
-   eliminar dependências entre Providers;
    
-   suportar múltiplas origens e destinos;
    
-   manter compatibilidade com Native AOT.
    

----------

# Non Goals

Esta SPEC não define:

-   SQL Compiler;
    
-   Materialization Pipeline;
    
-   Object Mapping;
    
-   Runtime.
    

Ela define apenas a arquitetura dos Providers.

----------

# Architecture

```text
Application
      │
      ▼
FlowMapper Runtime
      │
      ▼
Provider
      │
 ┌────┼─────────────────────────────────────┐
 ▼               ▼        ▼        ▼        ▼
SQL            Files    APIs     NoSQL   Custom

```

O Runtime conhece apenas contratos públicos.

----------

# Responsibilities

Cada Provider é responsável por:

-   estabelecer conexão com a tecnologia;
    
-   ler dados;
    
-   gravar dados;
    
-   produzir comandos de execução;
    
-   fornecer metadados específicos;
    
-   integrar-se ao Runtime.
    

Nenhum Provider implementa regras de negócio.

----------

# Provider Model

Cada Provider representa exatamente uma tecnologia.

Exemplos:

```text
SqlServer Provider

PostgreSQL Provider

Oracle Provider

MongoDB Provider

Csv Provider

Json Provider

Rest Provider

```

Todos utilizam a mesma infraestrutura.

----------

# Core Abstraction

Adicionar:

```csharp
public interface IDataProvider
{
    string Name { get; }

    Version Version { get; }
}

```

Todo Provider implementa essa abstração.

----------

# Provider Categories

Os Providers podem ser classificados em diferentes categorias.

```text
Provider
├── Database
├── File
├── API
├── Message
├── Document
└── Custom

```

A categoria possui finalidade apenas organizacional.

----------

# Execution Flow

O fluxo oficial é:

```text
Application
      │
      ▼
Runtime
      │
      ▼
Provider
      │
      ▼
Execution Artifact
      │
      ▼
Result

```

O Provider nunca interpreta configurações.

----------

# Provider Responsibilities

Um Provider pode produzir:

-   Connection;
    
-   Reader;
    
-   Writer;
    
-   Metadata;
    
-   Execution Commands;
    
-   Provider Artifacts.
    

Todo processamento complexo permanece no Compiler.

----------

# Provider Artifacts

Cada Provider pode produzir Artifacts específicos.

```text
SqlServer Provider

↓

SqlServer Artifact

```

```text
Csv Provider

↓

Csv Artifact

```

Esses Artifacts são produzidos durante a compilação.

----------

# Compiler Integration

Durante a compilação o Provider pode:

-   validar configurações;
    
-   produzir metadados;
    
-   gerar Delegates;
    
-   produzir Provider Artifacts.
    

Nenhuma dessas operações ocorre durante o Runtime.

----------

# Runtime Integration

O Runtime utiliza apenas contratos públicos.

```text
Execution Artifact

↓

Provider

↓

Execution

```

O Runtime permanece completamente desacoplado da tecnologia utilizada.

----------

# Materialization Integration

Todos os Providers utilizam exatamente o mesmo Materialization Pipeline.

```text
Provider

↓

Materialization Artifact

↓

Object

```

A materialização é independente da origem dos dados.

----------

# Mapping Integration

Todos os Providers utilizam o mesmo Mapping Pipeline.

```text
Provider

↓

Mapping Artifact

↓

Destination

```

Nenhum Provider implementa Object Mapping.

----------

# Provider Isolation

Cada Provider permanece completamente isolado.

```text
SqlServer

```

Não depende de:

```text
Oracle

```

Nem de:

```text
MongoDB

```

Cada implementação é independente.

----------

# Diagnostics Integration

Cada Provider pode registrar:

-   inicialização;
    
-   conexões;
    
-   comandos executados;
    
-   falhas;
    
-   tempo de execução.
    

Utilizando exclusivamente a infraestrutura de Diagnostics.

----------

# Metrics Integration

Cada Provider pode publicar:

-   tempo médio;
    
-   throughput;
    
-   quantidade de leituras;
    
-   quantidade de gravações;
    
-   erros.
    

Todas as métricas pertencem ao Runtime.

----------

# Configuration

Cada Provider possui suas próprias configurações.

Exemplos:

```text
SqlServerOptions

PostgreSqlOptions

CsvOptions

JsonOptions

```

As configurações permanecem isoladas.

----------

# Source Generator Integration

O Source Generator poderá gerar automaticamente:

-   Provider Registry;
    
-   Provider Metadata;
    
-   Provider Artifacts;
    
-   registro dos Providers.
    

Eliminando Reflection durante o Bootstrap.

----------

# Native AOT Compatibility

Todo Provider deve ser compatível com:

-   Native AOT;
    
-   Linker Trimming;
    
-   Source Generation.
    

Reflection durante o Runtime é proibida.

----------

# Extensibility

Novos Providers podem ser adicionados sem modificar o Core.

Exemplos:

```text
Apache Arrow

Parquet

Excel

GraphQL

gRPC

Redis

Elasticsearch

```

Todos utilizam exatamente a mesma arquitetura.

----------

# Performance Goals

Os Providers devem:

-   minimizar alocações;
    
-   reutilizar Execution Artifacts;
    
-   evitar Reflection;
    
-   utilizar Delegates gerados;
    
-   manter baixo custo de execução.
    

----------

# Design Rules

-   Todo Provider implementa `IDataProvider`.
    
-   O Runtime conhece apenas contratos públicos.
    
-   Providers são independentes entre si.
    
-   Providers nunca implementam regras de negócio.
    
-   Providers reutilizam Materialization e Mapping Pipelines.
    
-   Reflection durante o Runtime é proibida.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir `IDataProvider`;
    
-   Providers puderem representar qualquer tecnologia de origem ou destino;
    
-   Materialization e Mapping forem reutilizados por todos os Providers;
    
-   o Runtime permanecer desacoplado das tecnologias externas;
    
-   novos Providers puderem ser adicionados sem alterações no Core;
    
-   toda a arquitetura permanecer compatível com Native AOT.
    

----------

# Architecture Summary

A arquitetura de Providers estabelece uma camada única de integração entre o FlowMapper V2 e tecnologias externas.

Ao tratar bancos de dados, arquivos, APIs e outros formatos como implementações de um mesmo modelo arquitetural, a plataforma mantém o Core independente, reutiliza os mesmos Execution Artifacts e Pipelines para todas as tecnologias e permite expansão contínua sem comprometer a simplicidade, o desempenho ou a previsibilidade do sistema.

----------

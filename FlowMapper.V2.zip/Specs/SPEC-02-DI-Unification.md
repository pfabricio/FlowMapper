# SPEC-02: DI Unification

## Objetivo

Unificar `AddRapidMapper()` e `AddFlowMapper()` num único `AddFlowMapper()` com um builder que registra ambos os componentes.

## Referências

### Atual: RapidMapper DI (`ServiceCollectionExtensions.cs`)

```csharp
services.AddRapidMapper(builder =>
{
    builder.AddProvider<SqlServerProvider>();
    builder.AddDialect<SqlServerDialect>();
    builder.UseNamingStrategy<DefaultNamingStrategy>();
    builder.AddBehavior<LoggingBehavior>();
    builder.UseRetryStrategy(maxRetries: 3, initialDelayMs: 200);
    builder.UseCacheProvider<MemoryCacheProvider>();
    builder.Configure(options => { options.DefaultTimeout = 30; });
});
```

Registra:
- `INamingStrategy`, `IMapper`, `IExecutionScopeFactory`, `IExecutionStrategy`
- `IPipelineExecutor`, `IQueryExecutor`, `ICommandExecutor`, `IStreamExecutor`
- `IRapidMapper` (facade)
- Behaviors, providers, dialetos, cache (via builder)

### Atual: FlowMapper DI (`ServiceCollectionExtensions.cs`)

```csharp
services.AddFlowMapper(options =>
{
    options.EnableFlatten = true;
    options.Strictness = StrictnessLevel.Warning;
});
```

Registra:
- `FlowMapperOptions`
- `IFlowMapper`
- Scan de assemblies por implementações de `IMapper<,>` (geradas pelo source generator)

### Problemas atuais

1. Duas chamadas de registro separadas
2. `FlowMapperOptions` separado de `RapidMapperOptions`
3. Scan de assemblies só ocorre em runtime (`AppDomain.CurrentDomain.GetAssemblies()`)
4. Sem um builder único, configuração fica espalhada

## Proposta: `AddFlowMapper()` Unificado

```csharp
services.AddFlowMapper(builder =>
{
    // ===== Data Access (RapidMapper) =====
    builder.AddProvider<SqlServerProvider>();
    builder.AddDialect<SqlServerDialect>();
    builder.UseNamingStrategy<DefaultNamingStrategy>();
    builder.AddBehavior<LoggingBehavior>();
    builder.UseRetryStrategy(maxRetries: 3, initialDelayMs: 200);
    builder.UseCacheProvider<MemoryCacheProvider>();
    builder.ConfigureData(options =>
    {
        options.DefaultTimeout = 30;
        options.Mapping.Separator = "_";
    });

    // ===== Object Mapping (FlowMapper) =====
    builder.AddProfile<AppProfile>();
    builder.ConfigureMapping(options =>
    {
        options.EnableFlatten = true;
        options.Strictness = StrictnessLevel.Warning;
    });
});
```

## Implementação

### `FlowMapperBuilder.cs`

```csharp
namespace FlowMapper.DependencyInjection;

public class FlowMapperBuilder
{
    private readonly IServiceCollection _services;
    private readonly FlowMapperOptions _options;

    internal FlowMapperBuilder(IServiceCollection services)
    {
        _services = services;
        _options = new FlowMapperOptions();
    }

    // ========== Data Access Section ==========

    public FlowMapperBuilder AddProvider<TProvider>()
        where TProvider : class, IDatabaseProvider
    {
        _services.AddSingleton<IDatabaseProvider, TProvider>();
        return this;
    }

    public FlowMapperBuilder AddBehavior<TBehavior>()
        where TBehavior : class, IPipelineBehavior
    {
        _services.AddSingleton<IPipelineBehavior, TBehavior>();
        return this;
    }

    public FlowMapperBuilder AddDialect<TDialect>()
        where TDialect : class, IDialect
    {
        _services.AddSingleton<IDialect, TDialect>();
        return this;
    }

    public FlowMapperBuilder UseNamingStrategy<TStrategy>()
        where TStrategy : class, INamingStrategy
    {
        _services.AddSingleton<INamingStrategy, TStrategy>();
        return this;
    }

    public FlowMapperBuilder UseRetryStrategy(int maxRetries = 3, int initialDelayMs = 100)
    {
        _options.Data.Retry.Enabled = true;
        _options.Data.Retry.MaxRetries = maxRetries;
        _options.Data.Retry.InitialDelayMs = initialDelayMs;
        return this;
    }

    public FlowMapperBuilder UseCacheProvider<TCacheProvider>()
        where TCacheProvider : class, ICacheProvider
    {
        _services.AddSingleton<ICacheProvider, TCacheProvider>();
        return this;
    }

    public FlowMapperBuilder AddGenericProvider(string name, Func<IDbConnection> connectionFactory)
    {
        _services.AddSingleton<IDatabaseProvider>(
            new Data.GenericProvider(name, connectionFactory));
        return this;
    }

    public FlowMapperBuilder AddConnectionFactory(Func<IServiceProvider, IConnectionFactory> factory)
    {
        _services.AddSingleton(factory);
        return this;
    }

    public FlowMapperBuilder ConfigureData(Action<DataOptions> configure)
    {
        configure(_options.Data);
        return this;
    }

    // ========== Object Mapping Section ==========

    public FlowMapperBuilder AddProfile<TProfile>()
        where TProfile : ProfileDefinition, new()
    {
        _services.AddSingleton<TProfile>();
        return this;
    }

    public FlowMapperBuilder ConfigureMapping(Action<MappingOptionsSection> configure)
    {
        configure(_options.Mapping);
        return this;
    }

    // ========== Build ==========

    internal FlowMapperOptions GetOptions() => _options;
}
```

### `ServiceCollectionExtensions.cs`

```csharp
namespace FlowMapper.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddFlowMapper(
        this IServiceCollection services,
        Action<FlowMapperBuilder>? configure = null)
    {
        var builder = new FlowMapperBuilder(services);
        configure?.Invoke(builder);
        var options = builder.GetOptions();

        // ===== Registra opções =====
        services.AddSingleton(options);

        // ===== Data Access Services =====
        RegisterDataAccess(services, options.Data);

        // ===== Object Mapping Services =====
        RegisterObjectMapping(services);

        return services;
    }

    private static void RegisterDataAccess(IServiceCollection services, DataOptions options)
    {
        services.TryAddSingleton<INamingStrategy, DefaultNamingStrategy>();
        services.TryAddSingleton<Data.Mapping.DefaultMapper>();
        services.TryAddSingleton<IMapper>(sp => sp.GetRequiredService<Data.Mapping.DefaultMapper>());
        services.TryAddSingleton<IExecutionScopeFactory, Data.ExecutionScopeFactory>();

        // Estratégia de execução
        if (options.Retry.Enabled)
        {
            services.AddSingleton<IExecutionStrategy>(
                new RetryExecutionStrategy(
                    options.Retry.MaxRetries,
                    TimeSpan.FromMilliseconds(options.Retry.InitialDelayMs)));
        }
        else
        {
            services.TryAddSingleton<IExecutionStrategy, DefaultExecutionStrategy>();
        }

        // Pipeline
        services.AddSingleton<IPipelineExecutor>(sp => new Data.Pipeline.PipelineExecutor(
            sp.GetServices<IPipelineBehavior>(),
            sp.GetRequiredService<IDatabaseProvider>(),
            sp.GetRequiredService<IMapper>(),
            sp.GetRequiredService<IExecutionScopeFactory>(),
            sp.GetRequiredService<IExecutionStrategy>(),
            sp.GetService<ICacheProvider>()
        ));

        // Executores
        services.TryAddSingleton<IQueryExecutor, Data.QueryExecutor>();
        services.TryAddSingleton<ICommandExecutor, Data.CommandExecutor>();
        services.TryAddSingleton<IStreamExecutor, Data.StreamExecutor>();

        // Facade
        services.TryAddSingleton<IRapidMapper, Data.RapidMapper>();
    }

    private static void RegisterObjectMapping(IServiceCollection services)
    {
        services.AddSingleton<IFlowMapper, FlowMapperService>();

        // Scan de assemblies por IMapper<,> implementations
        var mapperTypes = AppDomain.CurrentDomain.GetAssemblies()
            .SelectMany(a =>
            {
                try { return a.GetTypes(); }
                catch (ReflectionTypeLoadException) { return Type.EmptyTypes; }
            })
            .Where(t => t is { IsClass: true, IsAbstract: false })
            .SelectMany(t => t.GetInterfaces()
                .Where(i => i.IsGenericType
                    && i.GetGenericTypeDefinition() == typeof(IMapper<,>))
                .Select(i => new { MapperType = t, ServiceType = i }))
            .ToList();

        foreach (var item in mapperTypes)
        {
            services.AddTransient(item.ServiceType, item.MapperType);
        }
    }
}
```

### `FlowMapperOptions.cs` (unificado)

```csharp
namespace FlowMapper.Abstractions;

public class FlowMapperOptions
{
    public DataOptions Data { get; init; } = new();
    public MappingOptionsSection Mapping { get; init; } = new();
}

public class DataOptions
{
    public int? DefaultTimeout { get; set; }
    public MappingOptions Mapping { get; set; } = new();
    public RetryOptions Retry { get; set; } = new();
}

public class RetryOptions
{
    public bool Enabled { get; set; }
    public int MaxRetries { get; set; } = 3;
    public int InitialDelayMs { get; set; } = 100;
}

public class MappingOptionsSection
{
    public string DefaultProfile { get; set; } = "Default";
    public bool EnableFlatten { get; set; } = true;
    public bool PreferConstructorMapping { get; set; }
    public StrictnessLevel Strictness { get; set; } = StrictnessLevel.None;
    public bool EnableCache { get; set; } = true;
}
```

## Uso final

```csharp
// Program.cs — uma única chamada
builder.Services.AddFlowMapper(builder =>
{
    // Data access
    builder.AddProvider<SqlServerProvider>();
    builder.AddDialect<SqlServerDialect>();
    builder.UseNamingStrategy<DefaultNamingStrategy>();

    // Object mapping
    builder.AddProfile<AppProfile>();
});

// Injeção — ambas as interfaces disponíveis
public class UsuarioRepository
{
    private readonly IRapidMapper _db;       // data access
    private readonly IFlowMapper _mapper;    // object mapping

    public UsuarioRepository(IRapidMapper db, IFlowMapper mapper)
    {
        _db = db;
        _mapper = mapper;
    }
}
```

## Critérios de aceitação

1. `AddFlowMapper()` registra todos os serviços do RapidMapper e FlowMapper
2. `IRapidMapper` pode ser injetado e usado para queries
3. `IFlowMapper` pode ser injetado e usado para object mapping
4. `IMapper<TSource, TDest>` gerado pelo source generator é registrado automaticamente
5. `FlowMapperBuilder` tem métodos fluent para configurar ambos os lados
6. Mantém compatibilidade: código que usava `AddRapidMapper()` continua funcionando após mudar namespace

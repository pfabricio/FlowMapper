# SPEC-01: Namespace Unification

## Objetivo

Unificar os namespaces do RapidMapper (`RapidMapper.*`) e FlowMapper (`FlowMapper.*`) num único projeto chamado `FlowMapper`, onde:
- `FlowMapper.Mapping` contém o object→object mapping (antigo FlowMapper)
- `FlowMapper.Data` contém o data access (antigo RapidMapper)
- Projetos de provider seguem o padrão `FlowMapper.Data.Provider.*`

## Referências

### Projetos existentes

**FlowMapper (origem: `D:\Programas Visuais\FlowMapper\src`):**
```
FlowMapper.Abstractions       → FlowMapper.Abstractions
FlowMapper.Core               → FlowMapper.Core
FlowMapper.SourceGenerator    → FlowMapper.SourceGenerator
FlowMapper.Analyzers          → FlowMapper.Analyzers
FlowMapper.DependencyInjection → FlowMapper.DependencyInjection
FlowMapper (meta)             → FlowMapper
FlowMapper.Cli                → FlowMapper.Cli
```

**RapidMapper (origem: `D:\Programas Visuais\RapidMapper`):**
```
RapidMapper.Abstractions        → será absorvido por FlowMapper.Abstractions
RapidMapper.Core                → será absorvido por FlowMapper.Core
RapidMapper.Mapping             → FlowMapper.Mapping
RapidMapper.Pipeline            → FlowMapper.Data.Pipeline
RapidMapper.Execution           → FlowMapper.Data
RapidMapper.DependencyInjection → será absorvido por FlowMapper.DependencyInjection
RapidMapper.Provider.SqlServer  → FlowMapper.Data.Provider.SqlServer
RapidMapper.Provider.PostgreSql → FlowMapper.Data.Provider.PostgreSql
RapidMapper.Provider.MySql      → FlowMapper.Data.Provider.MySql
RapidMapper.Provider.Oracle     → FlowMapper.Data.Provider.Oracle
RapidMapper (meta)              → será absorvido por FlowMapper (meta)
```

### Csproj targets atuais

| Projeto | Target |
|---------|--------|
| FlowMapper.* | `netstandard2.0` |
| RapidMapper.* | `net8.0` |
| FlowMapper.Cli | `net10.0` |

### Decisão sobre target

Usar `net8.0` como target único para todos os projetos de library para alinhar RapidMapper e FlowMapper.
Manter `net10.0` apenas para projetos executáveis (Cli, samples, tests).

## Projetos Resultantes

```
FlowMapper.slnx
├── src/
│   ├── FlowMapper.Abstractions/           [net8.0]
│   ├── FlowMapper.Core/                   [net8.0]
│   ├── FlowMapper.Mapping/                [net8.0]
│   ├── FlowMapper.Data/                   [net8.0]
│   │   └── Pipeline/
│   ├── FlowMapper.Data.Provider.SqlServer/ [net8.0]
│   ├── FlowMapper.Data.Provider.PostgreSql/[net8.0]
│   ├── FlowMapper.Data.Provider.MySql/    [net8.0]
│   ├── FlowMapper.Data.Provider.Oracle/   [net8.0]
│   ├── FlowMapper.SourceGenerator/        [netstandard2.0]*
│   ├── FlowMapper.Analyzers/              [netstandard2.0]*
│   ├── FlowMapper.DependencyInjection/    [net8.0]
│   ├── FlowMapper/                        [net8.0] (meta-package)
│   └── FlowMapper.Cli/                    [net10.0]
├── samples/
└── tests/
```

> *SourceGenerator e Analyzers mantêm `netstandard2.0` por exigência do Roslyn. Eles são empacotados como `analyzers\dotnet\cs`.

## Mapeamento de Namespaces

### FlowMapper.Mapping (object→object)

| Classe | Namespace |
|--------|-----------|
| `IMapper<TSource, TDest>` | `FlowMapper.Abstractions` |
| `FlowMapperOptions` | `FlowMapper.Abstractions` |
| `FlowProfileAttribute` | `FlowMapper.Abstractions` |
| `MapAttribute<TS, TD>` | `FlowMapper.Abstractions` |
| `MapPropertyAttribute` | `FlowMapper.Abstractions` |
| `IgnoreMapAttribute` | `FlowMapper.Abstractions` |
| `StrictnessLevel` | `FlowMapper.Abstractions` |
| `Flow` | `FlowMapper.Core` |
| `PropertyFlow` | `FlowMapper.Core` |
| `NestedFlow` | `FlowMapper.Core` |
| `MappingStrategy` | `FlowMapper.Core` |
| `MappingPolicy` | `FlowMapper.Core` |
| `MappingExpression<TS, TD>` | `FlowMapper.Core` |
| `ProfileDefinition` | `FlowMapper.Core` |
| `FlattenPath` | `FlowMapper.Core` |
| `ConstructorBinding` | `FlowMapper.Core` |
| `FlowSignature` | `FlowMapper.Core` |
| `IFlowMapper` | `FlowMapper.Abstractions` |
| `FlowMapperService` | `FlowMapper.DependencyInjection` |

### FlowMapper.Data (data access)

| Classe | Namespace |
|--------|-----------|
| `IRapidMapper` | `FlowMapper.Abstractions` (mantido como `IRapidMapper` ou renomeado para `IDataMapper`) |
| `IQueryExecutor` | `FlowMapper.Abstractions` |
| `ICommandExecutor` | `FlowMapper.Abstractions` |
| `IStreamExecutor` | `FlowMapper.Abstractions` |
| `IPipelineExecutor` | `FlowMapper.Abstractions` |
| `IPipelineBehavior` | `FlowMapper.Abstractions` |
| `IOrderedBehavior` | `FlowMapper.Abstractions` |
| `IExecutionStrategy` | `FlowMapper.Abstractions` |
| `IExecutionScope` | `FlowMapper.Abstractions` |
| `IExecutionScopeFactory` | `FlowMapper.Abstractions` |
| `IConnectionFactory` | `FlowMapper.Abstractions` |
| `IDatabaseProvider` | `FlowMapper.Abstractions` |
| `IDialect` | `FlowMapper.Abstractions` |
| `ICacheProvider` | `FlowMapper.Abstractions` |
| `INamingStrategy` | `FlowMapper.Abstractions` |
| `IMapper` (DataReader) | `FlowMapper.Abstractions` |
| `ExecutionContext<T>` | `FlowMapper.Abstractions` |
| `ExecutionMetrics` | `FlowMapper.Abstractions` |
| `ExecutionOptions` | `FlowMapper.Abstractions` |
| `ExecutionPhase` | `FlowMapper.Abstractions` |
| `ExecutionType` | `FlowMapper.Abstractions` |
| `MappingOptions` | `FlowMapper.Abstractions` |
| `RapidMapper` (facade) | `FlowMapper.Data` |
| `QueryExecutor` | `FlowMapper.Data` |
| `CommandExecutor` | `FlowMapper.Data` |
| `StreamExecutor` | `FlowMapper.Data` |
| `ConnectionFactory` | `FlowMapper.Data` |
| `DatabaseProvider` | `FlowMapper.Data` |
| `GenericProvider` | `FlowMapper.Data` |
| `ExecutionScope` | `FlowMapper.Data` |
| `ExecutionScopeFactory` | `FlowMapper.Data` |
| `PipelineExecutor` | `FlowMapper.Data.Pipeline` |
| `DefaultMapper` | `FlowMapper.Data.Mapping` |
| `MappingCache` | `FlowMapper.Data.Mapping` |
| `DefaultNamingStrategy` | `FlowMapper.Data.Mapping` |
| `SqlServerProvider` | `FlowMapper.Data.Provider.SqlServer` |
| `SqlServerDialect` | `FlowMapper.Data.Provider.SqlServer` |
| `PostgreSqlProvider` | `FlowMapper.Data.Provider.PostgreSql` |
| `PostgreSqlDialect` | `FlowMapper.Data.Provider.PostgreSql` |
| `MySqlProvider` | `FlowMapper.Data.Provider.MySql` |
| `MySqlDialect` | `FlowMapper.Data.Provider.MySql` |
| `OracleProvider` | `FlowMapper.Data.Provider.Oracle` |
| `OracleDialect` | `FlowMapper.Data.Provider.Oracle` |

## Sobre renomeação de `IRapidMapper`

**Decisão:** Manter `IRapidMapper` como nome da interface para não quebrar código existente. Adicionar `using FlowMapper.Data;` é suficiente.

Opcional: criar alias:
```csharp
// FlowMapper.Abstractions
using IDataMapper = IRapidMapper;
```

## Critérios de aceitação

1. Todos os csproj compilam individualmente
2. `FlowMapper.slnx` compila completo
3. Namespaces antigos (`RapidMapper.*`) não aparecem em lugar nenhum
4. `dotnet build` passa sem warnings de quebra
5. Testes existentes de ambos os projetos passam

## Anotações

- `FlowMapper.SourceGenerator` precisa empacotar `FlowMapper.Core.dll` como conteúdo (`analyzers\dotnet\cs`) - manter configuração existente
- `FlowMapper.Analyzers` também é empacotado como analyzer
- A dependência entre projetos obedece: `Abstractions → Core → {Mapping, Data, SourceGenerator} → DependencyInjection → FlowMapper (meta)`

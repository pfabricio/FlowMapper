# SPEC-215 — Build Integration

## Status

Draft

----------

# Purpose

Definir a arquitetura oficial de **Build Integration** do FlowMapper V2.

O Build Integration representa a camada responsável por integrar o Compiler do FlowMapper ao processo de compilação da aplicação.

Seu objetivo é transformar o Compiler em um participante nativo do Build, executando automaticamente todas as etapas necessárias antes da geração do assembly final.

----------

# Motivation

O Compiler do FlowMapper não deve depender de inicialização manual durante a execução da aplicação.

Todo o processo de:

-   descoberta;
    
-   validação;
    
-   otimização;
    
-   geração de código;
    
-   criação de Execution Artifacts;
    
-   montagem de Execution Plans;
    

deve ocorrer automaticamente durante o Build.

----------

# Goals

A arquitetura deve:

-   integrar o Compiler ao processo de Build;
    
-   automatizar a geração de código;
    
-   eliminar etapas manuais;
    
-   permitir integração com ferramentas de Build;
    
-   suportar compilação incremental;
    
-   manter compatibilidade com Native AOT.
    

----------

# Non Goals

Esta SPEC não define:

-   Compiler Pipeline;
    
-   Source Generator;
    
-   Runtime;
    
-   Dependency Injection.
    

Ela define exclusivamente a integração do Compiler com o processo de Build.

----------

# Architecture

```text
Developer
      │
      ▼
dotnet build
      │
      ▼
MSBuild
      │
      ▼
FlowMapper Build Integration
      │
      ▼
Compiler Pipeline
      │
      ▼
Generated Sources
      │
      ▼
Assembly

```

Todo o processo ocorre antes da geração do assembly.

----------

# Responsibilities

O Build Integration é responsável por:

-   inicializar o Compiler;
    
-   preparar o ambiente de compilação;
    
-   executar o Compiler Pipeline;
    
-   integrar Source Generators;
    
-   disponibilizar os resultados para o processo de Build.
    

Ele nunca participa do Runtime.

----------

# Build Flow

O fluxo oficial é:

```text
Build

↓

Build Integration

↓

Compiler Pipeline

↓

Generated Sources

↓

Assembly

```

Toda compilação passa por esse fluxo.

----------

# Core Abstraction

Adicionar:

```csharp
public interface IBuildIntegration
{
    CompilationResult Execute(BuildContext context);
}

```

Essa interface representa a entrada oficial do Compiler durante o Build.

----------

# Build Context

O processo de Build fornece um contexto compartilhado.

```text
Build Context
│
├── Project Metadata
├── Compilation Options
├── Plugin Registry
├── Dependency Graph
├── Compilation Cache
└── Build Environment

```

Todos os componentes utilizam esse contexto.

----------

# Compiler Pipeline Integration

O Build Integration executa integralmente o Compiler Pipeline.

```text
Build Integration

↓

Compiler Pipeline

↓

Compilation Result

```

Nenhum Stage é executado diretamente pelo MSBuild.

----------

# Source Generator Integration

Os Source Generators fazem parte do processo oficial de Build.

Exemplos de geração:

-   Mapping Delegates;
    
-   Materialization Delegates;
    
-   Provider Registries;
    
-   Execution Plans;
    
-   Bootstrap Code;
    
-   Factories.
    

Todo código gerado é incorporado automaticamente ao projeto.

----------

# Incremental Compilation Integration

O Build Integration utiliza:

-   Dependency Graph;
    
-   Compilation Cache;
    
-   Incremental Compilation.
    

Apenas componentes inválidos são recompilados.

----------

# Diagnostics Integration

Todos os Compiler Diagnostics são encaminhados ao processo de Build.

Exemplos:

-   erros;
    
-   avisos;
    
-   informações;
    
-   sugestões.
    

As mensagens podem ser exibidas diretamente na IDE ou na saída do Build.

----------

# Plugin Integration

Plugins podem participar do processo de Build.

Exemplos:

-   adicionar Stages;
    
-   registrar Source Generators;
    
-   adicionar Validation Rules;
    
-   registrar Optimization Passes.
    

Toda integração ocorre através do Compiler Pipeline.

----------

# MSBuild Integration

O Build Integration deve funcionar naturalmente com o MSBuild.

Fluxo:

```text
MSBuild

↓

FlowMapper Build Integration

↓

Compiler Pipeline

```

Nenhuma configuração manual deve ser necessária para projetos convencionais.

----------

# CLI Integration

A arquitetura também deve permitir execução através de ferramentas de linha de comando.

Exemplos:

```text
dotnet build

dotnet publish

dotnet pack

```

Todos utilizam exatamente a mesma infraestrutura.

----------

# IDE Integration

O Build Integration deve funcionar de forma transparente em:

-   Visual Studio;
    
-   Visual Studio Code;
    
-   JetBrains Rider.
    

Os resultados da compilação devem ser imediatamente refletidos na experiência do desenvolvedor.

----------

# Build Statistics

Ao final da compilação podem ser disponibilizadas estatísticas como:

-   tempo total de compilação;
    
-   tempo por Stage;
    
-   quantidade de Execution Plans;
    
-   quantidade de Artifacts;
    
-   cache hits;
    
-   cache misses;
    
-   código gerado.
    

Essas informações auxiliam na análise de desempenho do Compiler.

----------

# Native AOT Compatibility

O Build Integration deve produzir artefatos totalmente compatíveis com:

-   Native AOT;
    
-   Linker Trimming;
    
-   Source Generation.
    

Nenhum processamento adicional deve ocorrer durante o Runtime.

----------

# Performance Goals

O Build Integration deve:

-   minimizar impacto no tempo de Build;
    
-   reutilizar resultados válidos;
    
-   integrar-se ao Compilation Cache;
    
-   reduzir recompilações;
    
-   evitar geração desnecessária de código.
    

----------

# Design Rules

-   Todo o Compiler é executado durante o Build.
    
-   O Runtime nunca participa do processo de compilação.
    
-   O Compiler Pipeline é a única forma de gerar Execution Artifacts.
    
-   O Build Integration reutiliza Compilation Cache e Dependency Graph.
    
-   Source Generators fazem parte do processo oficial de Build.
    
-   Toda integração deve ser transparente para o desenvolvedor.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir um `IBuildIntegration`;
    
-   o Compiler puder ser executado automaticamente durante o Build;
    
-   Source Generators forem integrados ao processo de compilação;
    
-   o Build utilizar Compilation Cache e Incremental Compilation;
    
-   Compiler Diagnostics forem exibidos pela infraestrutura de Build;
    
-   os Execution Plans estiverem disponíveis antes da geração do assembly.
    

----------

# Architecture Summary

O Build Integration estabelece a integração definitiva entre o ecossistema .NET e o Compiler do FlowMapper V2.

Ao executar automaticamente o Compiler Pipeline durante o processo de Build, a plataforma transforma Reflection, validação, otimização, geração de código e criação de Execution Plans em etapas naturais da compilação da aplicação. O resultado é um Runtime extremamente leve, previsível e totalmente alinhado aos princípios de compilação antecipada, Native AOT e geração de código que fundamentam a arquitetura do FlowMapper V2.

----------

# Milestone Summary — Compiler Architecture

As SPECs **201–215** definem a arquitetura completa do Compiler do FlowMapper V2, cobrindo:

-   Execution Artifacts
    
-   Materialization Pipeline
    
-   Mapping Pipeline
    
-   Provider Architecture
    
-   SQL Compiler
    
-   Execution Plans
    
-   Metadata Model
    
-   Validation Engine
    
-   Compiler Diagnostics
    
-   Incremental Compilation
    
-   Optimization Engine
    
-   Compilation Cache
    
-   Plugin SDK
    
-   Compiler Pipeline
    
-   Build Integration
    

Em conjunto, essas SPECs estabelecem um modelo de compilação modular, incremental e orientado a artefatos, no qual praticamente todo o trabalho pesado é realizado em Build Time, permitindo que o Runtime permaneça pequeno, previsível e altamente otimizado.

---

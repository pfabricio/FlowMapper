# SPEC-208 — Validation Engine

## Status

Implemented

----------

# Purpose

Definir a arquitetura oficial do **Validation Engine** do FlowMapper V2.

O Validation Engine é responsável por analisar o **Metadata Model**, identificar inconsistências, validar regras arquiteturais e produzir diagnósticos antes da geração dos Execution Artifacts.

Nenhum componente do Compiler deve gerar código para metadados considerados inválidos.

----------

# Motivation

A validação durante a compilação permite detectar problemas antes da execução da aplicação.

Exemplos:

-   tipos incompatíveis;
    
-   propriedades inexistentes;
    
-   construtores inválidos;
    
-   configurações conflitantes;
    
-   Providers incompatíveis;
    
-   SQL inválido;
    
-   conversões impossíveis.
    

Detectar esses problemas em Build Time reduz falhas em produção e melhora a experiência do desenvolvedor.

----------

# Goals

A arquitetura deve:

-   validar toda a aplicação antes da geração de código;
    
-   centralizar todas as regras de validação;
    
-   produzir diagnósticos padronizados;
    
-   impedir geração de Artifacts inválidos;
    
-   suportar extensibilidade;
    
-   permitir validações específicas por Provider.
    

----------

# Non Goals

Esta SPEC não define:

-   Diagnostics;
    
-   Metadata Builder;
    
-   Source Generator;
    
-   Execution Plans.
    

Ela define apenas o mecanismo oficial de validação.

----------

# Architecture

```text
Metadata Model
      │
      ▼
Validation Engine
      │
 ┌────┼─────────────────────────────────┐
 ▼       ▼        ▼             ▼       ▼
Mapping SQL Materialization Providers Custom
      │
      ▼
Diagnostics

```

Toda validação parte do Metadata Model.

----------

# Responsibilities

O Validation Engine é responsável por:

-   validar tipos;
    
-   validar construtores;
    
-   validar membros;
    
-   validar configurações de Mapping;
    
-   validar Providers;
    
-   validar SQL;
    
-   produzir Diagnostics.
    

Ele nunca gera código.

----------

# Validation Flow

O fluxo oficial é:

```text
Metadata Model
      │
      ▼
Validation Rules
      │
      ▼
Diagnostics
      │
      ▼
Compiler Decision

```

Caso existam erros críticos, a compilação é interrompida.

----------

# Core Abstraction

Adicionar:

```csharp
public interface IValidationEngine
{
    ValidationResult Validate(IMetadataModel metadata);
}

```

O Validation Engine representa a entrada oficial para validação da compilação.

----------

# Validation Rules

Cada regra possui responsabilidade única.

Exemplos:

```text
Type Validation

Member Validation

Constructor Validation

Mapping Validation

Provider Validation

SQL Validation

```

As regras são independentes entre si.

----------

# Type Validation

Valida definições de tipos.

Exemplos:

-   tipos inexistentes;
    
-   tipos incompatíveis;
    
-   tipos duplicados;
    
-   ciclos inválidos.
    

----------

# Member Validation

Valida propriedades e campos.

Exemplos:

-   membro inexistente;
    
-   membro inacessível;
    
-   membro somente leitura;
    
-   tipo incompatível.
    

----------

# Constructor Validation

Valida construtores utilizados durante a materialização.

Exemplos:

-   construtor inexistente;
    
-   parâmetros incompatíveis;
    
-   múltiplos construtores ambíguos.
    

----------

# Mapping Validation

Valida configurações de Object Mapping.

Exemplos:

-   ForMember inválido;
    
-   ForPath inexistente;
    
-   Ignore duplicado;
    
-   ReverseMap inconsistente;
    
-   Flatten incompatível.
    

----------

# SQL Validation

Valida definições SQL.

Exemplos:

-   parâmetros inexistentes;
    
-   parâmetros duplicados;
    
-   tipos incompatíveis;
    
-   Dialect não suportado.
    

----------

# Provider Validation

Cada Provider pode registrar validadores específicos.

Exemplos:

```text
SqlServer Validation

PostgreSQL Validation

MongoDB Validation

```

Essas validações permanecem isoladas.

----------

# Custom Validation

A arquitetura permite validadores personalizados.

Fluxo:

```text
Metadata Model

↓

Custom Validator

↓

Diagnostics

```

Os validadores podem complementar as regras oficiais.

----------

# Validation Result

Toda validação produz um resultado estruturado.

Exemplo:

```text
Validation Result
│
├── Errors
├── Warnings
├── Information
└── Suggestions

```

O Compiler utiliza esse resultado para decidir se a compilação pode prosseguir.

----------

# Compiler Integration

O Validation Engine é executado antes de qualquer geração de código.

Fluxo:

```text
Metadata Builder

↓

Metadata Model

↓

Validation Engine

↓

Compiler

```

Nenhum Artifact é produzido antes da validação.

----------

# Diagnostics Integration

Todos os problemas encontrados são registrados através do sistema oficial de Diagnostics.

Cada diagnóstico deve possuir:

-   código único;
    
-   severidade;
    
-   descrição;
    
-   localização;
    
-   sugestão de correção.
    

----------

# Source Generator Integration

O Source Generator executa apenas após a validação bem-sucedida.

```text
Validation

↓

Source Generator

↓

Generated Code

```

Nenhum código é gerado para metadados inválidos.

----------

# Execution Plan Integration

Execution Plans somente podem ser produzidos quando não existirem erros críticos.

Fluxo:

```text
Validation

↓

Execution Artifacts

↓

Execution Plan

```

----------

# Extensibility

Novos módulos podem registrar regras adicionais de validação sem modificar o Core.

Exemplos:

-   Providers;
    
-   Plugins;
    
-   Extensions.
    

----------

# Native AOT Compatibility

O Validation Engine deve ser totalmente compatível com:

-   Native AOT;
    
-   Linker Trimming;
    
-   Source Generation.
    

Como faz parte do processo de compilação, nenhuma funcionalidade depende de Reflection durante o Runtime.

----------

# Performance Goals

O Validation Engine deve:

-   reutilizar o Metadata Model;
    
-   evitar validações duplicadas;
    
-   minimizar alocações;
    
-   executar apenas uma vez por compilação;
    
-   permitir paralelização quando possível.
    

----------

# Design Rules

-   Toda validação parte do Metadata Model.
    
-   O Validation Engine nunca gera código.
    
-   Nenhum Compiler ignora o resultado da validação.
    
-   Todos os diagnósticos utilizam a infraestrutura oficial.
    
-   Regras de validação possuem responsabilidade única.
    
-   Providers podem adicionar validadores específicos.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir um `IValidationEngine`;
    
-   todas as validações utilizarem o Metadata Model;
    
-   diagnósticos forem produzidos de forma padronizada;
    
-   Execution Artifacts não forem gerados quando existirem erros críticos;
    
-   Providers puderem registrar regras adicionais;
    
-   a arquitetura permanecer compatível com Native AOT.
    

----------

# Architecture Summary

O Validation Engine centraliza todas as regras de validação do FlowMapper V2, atuando como a etapa obrigatória entre a construção do Metadata Model e a geração dos Execution Artifacts.

Ao validar toda a estrutura da aplicação antes da compilação, a plataforma garante diagnósticos consistentes, reduz falhas em Runtime e estabelece uma base sólida para geração de código segura, previsível e alinhada aos princípios de compilação do FlowMapper V2.

----------

# SPEC-206 — Execution Plans

## Status

Implemented

----------

# Purpose

Definir a arquitetura oficial dos **Execution Plans** do FlowMapper V2.

O Execution Plan representa a unidade completa de execução produzida pelo Compiler.

Ele agrega todos os Execution Artifacts necessários para realizar uma operação e constitui a única entrada consumida pelo Runtime.

----------

# Motivation

Embora os Execution Artifacts representem unidades independentes de trabalho, a execução de uma operação normalmente depende da combinação de vários Artifacts.

Por exemplo:

-   Mapping;
    
-   Materialization;
    
-   SQL;
    
-   Providers;
    
-   Metadata.
    

O Runtime não deve conhecer esses componentes individualmente.

Ele deve executar apenas um Execution Plan previamente compilado.

----------

# Goals

A arquitetura deve:

-   centralizar todos os Execution Artifacts;
    
-   simplificar a interface entre Compiler e Runtime;
    
-   eliminar composição durante o Runtime;
    
-   permitir reutilização de planos;
    
-   suportar compilação incremental;
    
-   manter compatibilidade com Native AOT.
    

----------

# Non Goals

Esta SPEC não define:

-   Mapping Pipeline;
    
-   Materialization Pipeline;
    
-   SQL Compiler;
    
-   Providers.
    

Ela define apenas a composição dos Artifacts em um plano executável.

----------

# Architecture

```text
Profiles
      │
      ▼
Compiler
      │
      ▼
Execution Plan
      │
 ┌────┼────────────────────────────────────┐
 ▼            ▼          ▼      ▼          ▼
Mapping Materialization SQL Providers Metadata
      │
      ▼
Runtime

```

O Runtime conhece apenas o Execution Plan.

----------

# Responsibilities

O Execution Plan é responsável por:

-   agrupar Execution Artifacts;
    
-   representar uma operação compilada;
    
-   fornecer todas as informações necessárias ao Runtime;
    
-   eliminar composição dinâmica.
    

Ele nunca executa lógica de negócio.

----------

# Core Abstraction

Adicionar:

```csharp
public interface IExecutionPlan
{
    string Name { get; }

    Version Version { get; }
}

```

Todo plano implementa esse contrato.

----------

# Execution Plan Model

Um Execution Plan pode conter:

```text
Execution Plan
│
├── Mapping Artifact
├── Materialization Artifact
├── SQL Artifact
├── Provider Artifact
├── Metadata Artifact
└── Execution Delegate

```

Cada Artifact mantém sua responsabilidade individual.

----------

# Execution Delegate

Todo Execution Plan possui exatamente um Delegate principal.

```text
Execution Plan

↓

Execution Delegate

↓

Runtime

```

O Runtime executa apenas esse Delegate.

----------

# Compiler Integration

O Compiler é responsável por:

-   analisar Profiles;
    
-   validar configurações;
    
-   produzir Execution Artifacts;
    
-   montar o Execution Plan.
    

Todo esse processo ocorre durante a compilação.

----------

# Runtime Integration

O Runtime recebe exclusivamente um Execution Plan.

```text
Execution Plan

↓

Execution Delegate

↓

Result

```

O Runtime nunca compõe Artifacts.

----------

# Plan Composition

A composição ocorre apenas no Compiler.

Fluxo:

```text
Mapping Artifact
        │
Materialization Artifact
        │
SQL Artifact
        │
Provider Artifact
        ▼
Execution Plan

```

Após compilado, o plano torna-se imutável.

----------

# Execution Lifecycle

O ciclo oficial é:

```text
Profile

↓

Compiler

↓

Execution Artifacts

↓

Execution Plan

↓

Runtime

↓

Execution

```

Nenhuma etapa adicional ocorre durante a execução.

----------

# Registry

Adicionar:

```csharp
public interface IExecutionPlanRegistry
{
    IReadOnlyCollection<IExecutionPlan> Plans { get; }
}

```

Todos os planos compilados pertencem ao Registry.

----------

# Immutability

Após compilado:

-   nenhum Artifact pode ser alterado;
    
-   nenhuma composição adicional é permitida;
    
-   nenhum Delegate pode ser substituído.
    

Execution Plans são completamente imutáveis.

----------

# Incremental Compilation

Cada plano pode ser recompilado independentemente.

```text
Order Mapping

↓

Execution Plan A

Customer Mapping

↓

Execution Plan B

```

A alteração de um plano não exige recompilar todos os demais.

----------

# Diagnostics Integration

Durante a compilação podem ser registrados:

-   Artifacts utilizados;
    
-   tempo de compilação;
    
-   otimizações aplicadas;
    
-   dependências;
    
-   diagnósticos.
    

Essas informações pertencem ao Compiler.

----------

# Source Generator Integration

O Source Generator poderá gerar automaticamente:

-   Execution Plans;
    
-   Plan Registry;
    
-   Execution Delegates;
    
-   Metadata.
    

Todo o código é produzido durante o Build.

----------

# Native AOT Compatibility

Execution Plans devem ser totalmente compatíveis com:

-   Native AOT;
    
-   Linker Trimming;
    
-   Source Generation.
    

Reflection durante o Runtime é proibida.

----------

# Performance Goals

Os Execution Plans devem:

-   evitar composição durante o Runtime;
    
-   reutilizar Artifacts compilados;
    
-   minimizar alocações;
    
-   utilizar apenas Delegates gerados;
    
-   reduzir Startup.
    

----------

# Design Rules

-   Apenas o Compiler cria Execution Plans.
    
-   O Runtime conhece apenas Execution Plans.
    
-   Execution Plans são imutáveis.
    
-   Toda composição ocorre durante a compilação.
    
-   Todo plano possui exatamente um Execution Delegate.
    
-   Reflection durante o Runtime é proibida.
    

----------

# Acceptance Criteria

Esta SPEC estará concluída quando:

-   existir `IExecutionPlan`;
    
-   existir `IExecutionPlanRegistry`;
    
-   o Compiler produzir Execution Plans completos;
    
-   o Runtime consumir exclusivamente Execution Plans;
    
-   toda composição ocorrer durante a compilação;
    
-   a arquitetura permanecer compatível com Native AOT.
    

----------

# Architecture Summary

Execution Plans representam a unidade oficial de execução do FlowMapper V2.

Ao agrupar todos os Execution Artifacts em uma estrutura única e imutável, o Compiler entrega ao Runtime um plano completamente preparado para execução. Essa abordagem elimina composição dinâmica, simplifica a arquitetura e reforça o princípio fundamental da plataforma: **compilar o máximo possível e executar apenas o necessário**.

----------

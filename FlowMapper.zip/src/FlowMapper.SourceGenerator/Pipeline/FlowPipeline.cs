using FlowMapper.Core;
using FlowMapper.SourceGenerator.Models;
using FlowMapper.SourceGenerator.Performance;
using FlowMapper.SourceGenerator.Pipeline.Builder;
using FlowMapper.SourceGenerator.Pipeline.Validator;

namespace FlowMapper.SourceGenerator.Pipeline;

public static class FlowPipeline
{
    public static FlowModel Execute(IReadOnlyList<MappingCandidate> candidates)
    {
        var cache = new FlowCache();
        var flows = new List<Flow>();
        var mapperName = string.Empty;
        var diagnostics = new List<FlowDiagnosticResult>();

        foreach (var candidate in candidates)
        {
            var flow = FlowBuilder.Build(candidate, cache);
            flows.Add(flow);

            var name = candidate.MapperName ?? candidate.MapperType.Name;
            if (string.IsNullOrEmpty(mapperName))
                mapperName = name;
            else if (mapperName != name)
                mapperName = "AggregateMapper";

            diagnostics.AddRange(FlowValidator.Validate(candidate, flow));
        }

        return new FlowModel(flows, mapperName, diagnostics);
    }
}

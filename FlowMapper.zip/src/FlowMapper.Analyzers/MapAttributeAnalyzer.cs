using System.Collections.Immutable;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;

namespace FlowMapper.Analyzers;

[DiagnosticAnalyzer(LanguageNames.CSharp)]
public class MapAttributeAnalyzer : DiagnosticAnalyzer
{
    public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics =>
        ImmutableArray.Create(
            DiagnosticDescriptors.MapAttributeInvalid,
            DiagnosticDescriptors.MissingMapAttribute);

    public override void Initialize(AnalysisContext context)
    {
        context.ConfigureGeneratedCodeAnalysis(GeneratedCodeAnalysisFlags.None);
        context.EnableConcurrentExecution();
        context.RegisterSymbolAction(AnalyzeNamedType, SymbolKind.NamedType);
    }

    private static void AnalyzeNamedType(SymbolAnalysisContext context)
    {
        var typeSymbol = (INamedTypeSymbol)context.Symbol;

        if (typeSymbol.DeclaredAccessibility != Accessibility.Public)
            return;

        var hasMapAttribute = typeSymbol.GetAttributes()
            .Any(a => a.AttributeClass?.Name == "MapAttribute");

        var implementsIMapper = typeSymbol.AllInterfaces
            .Any(i => i.OriginalDefinition?.Name == "IMapper"
                      && i.OriginalDefinition?.TypeArguments.Length == 2);

        if (hasMapAttribute && !implementsIMapper)
        {
            var diag = Diagnostic.Create(
                DiagnosticDescriptors.MapAttributeInvalid,
                typeSymbol.Locations[0],
                typeSymbol.Name,
                "Class must implement IMapper<TSource, TDestination>");
            context.ReportDiagnostic(diag);
        }

        if (!hasMapAttribute && implementsIMapper)
        {
            var diag = Diagnostic.Create(
                DiagnosticDescriptors.MissingMapAttribute,
                typeSymbol.Locations[0],
                typeSymbol.Name);
            context.ReportDiagnostic(diag);
        }
    }
}

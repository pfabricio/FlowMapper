using System.Collections.Immutable;
using System.Composition;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CodeActions;
using Microsoft.CodeAnalysis.CodeFixes;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace FlowMapper.Analyzers;

[ExportCodeFixProvider(LanguageNames.CSharp, Name = nameof(AddMapAttributeCodeFixProvider))]
[Shared]
public class AddMapAttributeCodeFixProvider : CodeFixProvider
{
    public override ImmutableArray<string> FixableDiagnosticIds =>
        ImmutableArray.Create(DiagnosticDescriptors.MissingMapAttribute.Id);

    public override FixAllProvider GetFixAllProvider() => WellKnownFixAllProviders.BatchFixer;

    public override async Task RegisterCodeFixesAsync(CodeFixContext context)
    {
        var root = await context.Document.GetSyntaxRootAsync(context.CancellationToken)
            .ConfigureAwait(false);
        if (root == null) return;

        var diagnostic = context.Diagnostics.First();
        var diagnosticSpan = diagnostic.Location.SourceSpan;

        var classDecl = root.FindToken(diagnosticSpan.Start).Parent?
            .AncestorsAndSelf()
            .OfType<ClassDeclarationSyntax>()
            .FirstOrDefault();

        if (classDecl == null) return;

        context.RegisterCodeFix(
            CodeAction.Create(
                title: "Add [Map<,>] attribute",
                createChangedSolution: ct => AddMapAttributeAsync(
                    context.Document, classDecl, ct),
                equivalenceKey: "AddMapAttribute"),
            diagnostic);
    }

    private static async Task<Solution> AddMapAttributeAsync(
        Document document,
        ClassDeclarationSyntax classDecl,
        CancellationToken ct)
    {
        var model = await document.GetSemanticModelAsync(ct).ConfigureAwait(false);
        if (model == null) return document.Project.Solution;

        var typeSymbol = model.GetDeclaredSymbol(classDecl, ct) as INamedTypeSymbol;
        if (typeSymbol == null) return document.Project.Solution;

        var mapperInterface = typeSymbol.AllInterfaces
            .FirstOrDefault(i => i.OriginalDefinition?.Name == "IMapper");

        if (mapperInterface?.TypeArguments.Length != 2)
            return document.Project.Solution;

        var srcType = mapperInterface.TypeArguments[0];
        var dstType = mapperInterface.TypeArguments[1];

        var mapAttr = SyntaxFactory.Attribute(
            SyntaxFactory.ParseName($"Map<{srcType.Name}, {dstType.Name}>"));

        var newClassDecl = classDecl.AddAttributeLists(
            SyntaxFactory.AttributeList(SyntaxFactory.SingletonSeparatedList(mapAttr))
                .WithLeadingTrivia(classDecl.GetLeadingTrivia())
                .WithTrailingTrivia(SyntaxFactory.ElasticCarriageReturnLineFeed));

        var root = await document.GetSyntaxRootAsync(ct).ConfigureAwait(false);
        if (root == null) return document.Project.Solution;

        var newRoot = root.ReplaceNode(classDecl, newClassDecl);
        return document.WithSyntaxRoot(newRoot).Project.Solution;
    }
}
